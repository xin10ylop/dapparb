{{ config(
    schema = 'dex_base'
    , alias = 'base_trades'
    , partition_by = ['block_month']
    , materialized = 'incremental'
    , file_format = 'delta'
    , incremental_strategy = 'merge'
    , unique_key = ['blockchain', 'project', 'version', 'tx_hash', 'evt_index']
    , incremental_predicates = [incremental_predicate('DBT_INTERNAL_DEST.block_time')]
    )
}}

{% set base_models = [
    ref('uniswap_v4_base_base_trades')
    , ref('uniswap_v3_base_base_trades')
    , ref('uniswap_v2_base_base_trades')
    , ref('sushiswap_v1_base_base_trades')
    , ref('sushiswap_v2_base_base_trades')
    , ref('stablebase_base_base_trades')
    , ref('aerodrome_base_base_trades')
    , ref('pancakeswap_v2_base_base_trades')
    , ref('pancakeswap_v3_base_base_trades')
    , ref('pancakeswap_infinity_base_base_trades')
    , ref('balancer_v2_base_base_trades')
    , ref('balancer_v3_base_base_trades')
    , ref('dodo_base_base_trades')
    , ref('maverick_base_base_trades')
    , ref('maverick_v2_base_base_trades')
    , ref('smardex_base_base_trades')
    , ref('dackieswap_base_base_trades')
    , ref('rubicon_base_base_trades')
    , ref('baseswap_base_base_trades')
    , ref('baseswap_v3_base_base_trades')
    , ref('scale_base_base_trades')
    , ref('kyberswap_base_base_trades')
    , ref('woofi_base_base_trades')
    , ref('velocimeter_v2_base_base_trades')
    , ref('moonbase_base_base_trades')
    , ref('horizondex_base_base_trades')
    , ref('plantbaseswap_base_base_trades')
    , ref('sobal_base_base_trades')
    , ref('derpdex_base_base_trades')
    , ref('torus_base_base_trades')
    , ref('throne_exchange_v2_base_base_trades')
    , ref('throne_exchange_v3_base_base_trades')
    , ref('sharkswap_base_base_trades')
    , ref('citadelswap_base_base_trades')
    , ref('autotronic_base_base_trades')
    , ref('soswap_base_base_trades')
    , ref('elk_finance_base_base_trades')
    , ref('oasisswap_base_base_trades')
    , ref('leetswap_v2_base_base_trades')
    , ref('wombat_exchange_base_base_trades')
    , ref('rocketswap_base_base_trades')
    , ref('alienbase_base_base_trades')
    , ref('alienbase_v3_base_base_trades')
    , ref('swapbased_base_base_trades')
    , ref('clipper_base_base_trades')
    , ref('solidly_v3_base_base_trades')
    , ref('swaap_v2_base_base_trades')
    , ref('xchange_base_base_trades')
    , ref('infusion_base_base_trades')
    , ref('flashliquidity_base_base_trades')
    , ref('akronswap_base_base_trades')
    , ref('jojo_base_base_trades')
    , ref('otsea_base_base_trades')
    , ref('tapio_base_base_trades')
    , ref('fluid_v1_base_base_trades')
    , ref('native_base_base_trades')
    , ref('carbon_defi_base_base_trades')
    , ref('elfomofi_base_base_trades')
    , ref('tessera_v_base_base_trades')
    , ref('zeroex_settler_base_base_trades')
    , ref('metric_base_base_trades')
] %}

{{ dex_base_trades_macro(
    blockchain = 'base',
    base_models = base_models
) }}
