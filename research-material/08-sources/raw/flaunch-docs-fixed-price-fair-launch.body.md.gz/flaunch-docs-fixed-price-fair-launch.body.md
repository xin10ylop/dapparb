> For the complete documentation index, see [llms.txt](https://docs.flaunch.gg/llms.txt). Markdown versions of documentation pages are available by appending `.md` to page URLs; this page is available as [Markdown](https://docs.flaunch.gg/features/fixed-price-fair-launch.md).

# Fixed Price Fair Launch

When a coin is flaunched it enters into a Fixed Price Fair Launch. During this period a set number of coins are available to buy at a fixed price *for everyone*. This levels the playing field for all traders—from degens to bots.

<figure><img src="https://1229184497-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2FoleIQgpsdD3uHYHcTay2%2Fuploads%2FMMTU8wlqnspXOg5jQxT9%2Fimage.png?alt=media&amp;token=4eb30925-9ad1-4945-ad4a-789880a78c65" alt="" width="375"><figcaption><p>Everyone gets the same price for the first 30 minutes.</p></figcaption></figure>

{% hint style="success" %}
Buys during Fixed Price Fair Launch can be sold at the same price (minus fees), removing price risk entirely.
{% endhint %}

{% hint style="danger" %}
It is possible to buy more than the remaining Fair Launch amount, any additional amounts will not be protected by the fixed price.
{% endhint %}

While a Fair Launch is active, coins that are purchased cannot be sold. Coins that were purchased during Fair Launch can be sold at the same price they were bought for (minus fees). This reduces ape risk and gives early supporters a chance to enter before price discovery kicks in.

Creators also have the option to buy up some of their Fair Launch tokens before they become available to the public (and at the same price). This gives creators the flexibility to ensure they have skin in the game or to use these early coins for distribution later on.


---

# Agent Instructions
This documentation is published with GitBook. GitBook is the documentation platform designed so that both humans and AI agents can read, navigate, and reason over technical content effectively. Learn more at gitbook.com.

## Querying This Documentation
If you need additional information that is not directly available in this page, you can query the documentation dynamically by asking a question.

Perform an HTTP GET request on the current page URL with the `ask` query parameter, and the optional `goal` query parameter:

```
GET https://docs.flaunch.gg/features/fixed-price-fair-launch.md?ask=<question>&goal=<endgoal>
```

`ask` is the immediate question: it should be specific, self-contained, and written in natural language.
`goal` is optional and describes the broader end goal you are ultimately trying to accomplish on behalf of the user. GitBook uses it to tailor the answer towards what is most useful for that goal.

The response will contain a direct answer to the question and relevant excerpts and sources from the documentation.

Use this mechanism when the answer is not explicitly present in the current page, you need clarification or additional context, or you want to retrieve related documentation sections.
