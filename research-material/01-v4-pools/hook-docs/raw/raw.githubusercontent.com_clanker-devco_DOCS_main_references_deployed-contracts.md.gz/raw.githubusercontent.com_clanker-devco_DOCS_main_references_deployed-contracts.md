# Deployed Contracts

## Mainnet Deployments

### Base: 8453

<details>

<summary>v4.1.0</summary>

| Contract                      | Contract Address                           |
| ----------------------------- | ------------------------------------------ |
| ClankerHookDynamicFeeV2       | 0xd60D6B218116cFd801E28F78d011a203D2b068Cc |
| ClankerHookStaticFeeV2        | 0xb429d62f8f3bFFb98CdB9569533eA23bF0Ba28CC |
| ClankerSniperAuctionV2        | 0xebB25BB797D82CB78E1bc70406b13233c0854413 |
| ClankerSniperUtilV2           | 0xC5AA2945d52a4096b946891ef8e01668f82eB74E |
| ClankerAirdropV2              | 0xf652B3610D75D81871bf96DB50825d9af28391E0 |
| ClankerPoolExtensionAllowlist | 0xaa12bb11E9876FCAFc7c46dBEB985d3fA23832c9 |

</details>

<details>

<summary>v4.0.0</summary>

| Contract                     | Contract Address                           |
| ---------------------------- | ------------------------------------------ |
| Clanker                      | 0xE85A59c628F7d27878ACeB4bf3b35733630083a9 |
| ClankerFeeLocker             | 0xF3622742b1E446D92e45E22923Ef11C2fcD55D68 |
| ClankerLpLockerFeeConversion | 0x63D2DfEA64b3433F4071A98665bcD7Ca14d93496 |
| ClankerVault                 | 0x8E845EAd15737bF71904A30BdDD3aEE76d6ADF6C |
| ClankerAirdrop               | 0x56Fa0Da89eD94822e46734e736d34Cab72dF344F |
| ClankerUniv4EthDevBuy        | 0x1331f0788F9c08C8F38D52c7a1152250A9dE00be |
| ClankerMevBlockDelay         | 0xE143f9872A33c955F23cF442BB4B1EFB3A7402A2 |
| ClankerSniperAuctionV0       | 0xFdc013ce003980889cFfd66b0c8329545ae1d1E8 |
| ClankerSniperUtilV0          | 0x8806169969aE96bfaaDb3eFd4B10785BEEb321b3 |
| ClankerHookDynamicFee        | 0x34a45c6B61876d739400Bd71228CbcbD4F53E8cC |
| ClankerHookStaticFee         | 0xDd5EeaFf7BD481AD55Db083062b13a3cdf0A68CC |
| ClankerLpLocker              | 0x29d17C1A8D851d7d4cA97FAe97AcAdb398D9cCE0 |

</details>

<details>

<summary>v3.1.0</summary>

| Contract     | Contract Address                           |
| ------------ | ------------------------------------------ |
| Clanker      | 0x2A787b2362021cC3eEa3C24C4748a6cD5B687382 |
| LpLockerv2   | 0x33e2Eda238edcF470309b8c6D228986A1204c8f9 |
| ClankerVault | 0x42A95190B4088C88Dd904d930c79deC1158bF09D |

</details>

<details>

<summary>v3.0.0</summary>

| Contract       | Contract Address                           |
| -------------- | ------------------------------------------ |
| Clanker        | 0x375C15db32D28cEcdcAB5C03Ab889bf15cbD2c5E |
| ClankerPreSale | 0x71cDc0bDF30F5601fb0ac80Cf1d20B771342C035 |
| LPLockerv2     | 0x5eC4f99F342038c67a312a166Ff56e6D70383D86 |

</details>

<details>

<summary>v2.0.0</summary>

| Contract   | Contract Address                           |
| ---------- | ------------------------------------------ |
| Clanker    | 0x732560fa1d1A76350b1A500155BA978031B53833 |
| LPLockerv2 | 0x618A9840691334eE8d24445a4AdA4284Bf42417D |

</details>

<details>

<summary>v1.0.0</summary>

| Contract      | Contract Address                           |
| ------------- | ------------------------------------------ |
| Clanker       | 0x9B84fcE5Dcd9a38d2D01d5D72373F6b6b067c3e1 |
| LockerFactory | 0x18db5Fce22bE8814B7E31FBDA2f6488d607A1172 |

</details>

<details>

<summary>v0.0.0</summary>

| Contract          | Contract Address                           |
| ----------------- | ------------------------------------------ |
| SocialDexDeployer | 0x250c9FB2b411B48273f69879007803790A6AeA47 |
| LockerFactory     | 0x515d45F06EdD179565aa2796388417ED65E88939 |

</details>

### Arbitrum One: 42161

<details>

<summary>v4.1.0</summary>

| Contract         | Contract Address                           |
| ---------------- | ------------------------------------------ |
| ClankerAirdropV2 | 0x8Cb6e0216e98A7ACF622DC2dD6a39F1b4FF37014 |

</details>

<details>

<summary>v4.0.0</summary>

| Contract                     | Contract Address                           |
| ---------------------------- | ------------------------------------------ |
| Clanker                      | 0xEb9D2A726Edffc887a574dC7f46b3a3638E8E44f |
| ClankerFeeLocker             | 0x92C0DCbAba17b0F5f3a7537dA82c0F80520e4dF6 |
| ClankerLpLockerFeeConversion | 0xF3622742b1E446D92e45E22923Ef11C2fcD55D68 |
| ClankerVault                 | 0xa1da0600Eb4A9F3D4a892feAa2c2caf80A4A2f14 |
| ClankerAirdrop               | 0x303470b6b6a35B06A5A05763A7caD776fbf27B71 |
| ClankerUniv4EthDevBuy        | 0x70aDdc06fE89a5cF9E533aea8D025dB06795e492 |
| ClankerMevBlockDelay         | 0x4E35277306a83D00E13e8C8A4307C672FA31FC99 |
| ClankerHookDynamicFee        | 0xFd213BE7883db36e1049dC42f5BD6A0ec66B68cC |
| ClankerHookStaticFee         | 0xf7aC669593d2D9D01026Fa5B756DD5B4f7aAa8Cc |

</details>

### Unichain: 130

<details>

<summary>v4.1.0</summary>

| Contract         | Contract Address                           |
| ---------------- | ------------------------------------------ |
| ClankerAirdropV2 | 0xE143f9872A33c955F23cF442BB4B1EFB3A7402A2 |

</details>

<details>

<summary>v4.0.0</summary>

| Contract                     | Contract Address                           |
| ---------------------------- | ------------------------------------------ |
| Clanker                      | 0xE85A59c628F7d27878ACeB4bf3b35733630083a9 |
| ClankerFeeLocker             | 0x1d5A0F0BD3eA07F78FC14577f053de7A3FEc35B2 |
| ClankerLpLockerFeeConversion | 0x691f97752E91feAcD7933F32a1FEdCeDae7bB59c |
| ClankerVault                 | 0xA9C0a423f0092176fC48d7B50a1fCae8cf5BB441 |
| ClankerAirdrop               | 0x35bfE89d95F26674bF06bB8bFE55f8D73E9280D2 |
| ClankerUniv4EthDevBuy        | 0x267259e36914839Eb584e962558563760AE28862 |
| ClankerMevBlockDelay         | 0x42A95190B4088C88Dd904d930c79deC1158bF09D |
| ClankerHookDynamicFee        | 0x9b37A43422D7bBD4C8B231be11E50AD1acE828CC |
| ClankerHookStaticFee         | 0xBc6e5aBDa425309c2534Bc2bC92562F5419ce8Cc |
| ClankerSniperAuctionV0       | 0x78B512C5074a1084bf3b8e6cbA8a1710d2a8d0A2 |
| ClankerSniperUtilV0          | 0xA25e594869ddb46c33233A793E3c8b207CC719a2 |

</details>

### Mainnet: 1

<details>

<summary>v4.1.0</summary>

| Contract         | Contract Address                           |
| ---------------- | ------------------------------------------ |
| ClankerAirdropV2 | 0x303470b6b6a35B06A5A05763A7caD776fbf27B71 |

</details>

<details>

<summary>v4.0.0</summary>

| Contract                     | Contract Address                           |
| ---------------------------- | ------------------------------------------ |
| Clanker                      | 0x6C8599779B03B00AAaE63C6378830919Abb75473 |
| ClankerFeeLocker             | 0xA9C0a423f0092176fC48d7B50a1fCae8cf5BB441 |
| ClankerLpLockerFeeConversion | 0x00C4b21889145CF0D99f2e05919103e0c3991974 |
| ClankerVault                 | 0xa1da0600Eb4A9F3D4a892feAa2c2caf80A4A2f14 |
| ClankerAirdrop               | 0x303470b6b6a35B06A5A05763A7caD776fbf27B71 |
| ClankerUniv4EthDevBuy        | 0x70aDdc06fE89a5cF9E533aea8D025dB06795e492 |
| ClankerMevBlockDelay         | 0x33e2Eda238edcF470309b8c6D228986A1204c8f9 |
| ClankerHookDynamicFee        | not supported                              |
| ClankerHookStaticFee         | 0x6C24D0bCC264EF6A740754A11cA579b9d225e8Cc |
| ClankerSniperAuctionV0       | 0x33e2Eda238edcF470309b8c6D228986A1204c8f9 |
| ClankerSniperUtilV0          | 0x33e2Eda238edcF470309b8c6D228986A1204c8f9 |

</details>

## Binance: 97

<details>

<summary>v4.1.0</summary>

| Contract         | Contract Address                           |
| ---------------- | ------------------------------------------ |
| ClankerAirdropV2 | 0xBB0f069b995e0205cD5F92C84a1dF056a3F47900 |

</details>

<details>

<summary>v4.0.0</summary>

| Contract                     | Contract Address                           |
| ---------------------------- | ------------------------------------------ |
| Clanker                      | 0xea30438E0B5f99096cb05A8Da63be55A6A298F6a |
| ClankerFeeLocker             | 0x67D04Ae42F03D9b63dE0E6F2d82bB186A0306bBb |
| ClankerLpLockerFeeConversion | 0x1166022e1becc70E7E9aB2250aF1aC7842B9B420 |
| ClankerVault                 | 0x15ee8382DBd8Fb991F653B59CA11bf504a07372D |
| ClankerAirdrop               | 0xBB0f069b995e0205cD5F92C84a1dF056a3F47900 |
| ClankerUniv4EthDevBuy        | 0x302989E1cA167B6E78f9711e5a08d1BD555DdAc4 |
| ClankerMevBlockDelay         | 0x33e2Eda238edcF470309b8c6D228986A1204c8f9 |
| ClankerHookDynamicFee        | 0x011a8ed40095F2D7E9c19125B8254b19678D68Cc |
| ClankerHookStaticFee         | 0xC5d309026BCAb6630888d51CE21154AD2f4828cC |
| mevModuleV2                  | 0xec1310cf227a2D671176000aE0849DE6417b175a |
| mevModule                    | 0xEE2940CC010820B7F22DF627e081d707693989a6 |

</details>

## Monad: 143

<details>

<summary>v4.1.0</summary>

| Contract                     | Contract Address                           |
| ---------------------------- | ---------------------------------------------------------- |
| Clanker                      | 0xF9a0C289Eab6B571c6247094a853810987E5B26D                 |
| ClankerFeeLocker             | 0xDe51a86D3b6EC9ac4756115D3744335Aa2c30144                 |
| ClankerLpLockerFeeConversion | 0x46B77BaCFd712D79131F1AD7611794869483C353                 |
| ClankerVault                 | 0xe7D402A5BEd94E5c49Ac0639E80f784D06E2D397                 |
| ClankerAirdrop               | 0x654E7221fa51d4359ded21D524E3AfF18e93A507                 |
| ClankerUniv4EthDevBuy        | 0x8790d79283eB941c719b616CfD0Ef116D13C7683                 |
| ClankerMevBlockDelay         | 0x3231D1ddfdC4Ad585cF1939FfEcd9c88b338Dbf2                 |
| ClankerHookDynamicFee        | 0x0000000000000000000000000000000000000000 (not supported) |
| ClankerHookStaticFee         | 0x94F802a9EFE4dd542FdBd77a25D9e69A6dC828Cc                 |
| mevModuleV2                  | 0x3231D1ddfdC4Ad585cF1939FfEcd9c88b338Dbf2                 |
| mevModule                    | 0x3231D1ddfdC4Ad585cF1939FfEcd9c88b338Dbf2                 |

</details>

## Solana

Tag `@clanker` on Farcaster or `@clanker_world` on X to deploy a Meteora token on Solana.

## Testnet Deployments

### Base Sepolia: 84532

<details>

<summary>v4.1.0</summary>

| Contract                      | Contract Address                           |
| ----------------------------- | ------------------------------------------ |
| ClankerHookDynamicFeeV2       | 0xBF4983dC0f2F8FE78C5cf8Fc621f294A993728Cc |
| ClankerHookStaticFeeV2        | 0x11b51DBC2f7F683b81CeDa83DC0078D57bA328cc |
| ClankerSniperAuctionV2        | 0x8CBD6694A9DFc0eF4D1cd333e013B88E7003E10A |
| ClankerSniperUtilV2           | 0x4DC6348D38E3e199D7Ea032c8cfE4EbDe94b442A |
| ClankerAirdropV2              | 0x5c68F1560a5913c176Fc5238038098970B567B19 |
| ClankerPoolExtensionAllowlist | 0x532d79D18F0F1782884662fCC1e74581A3289680 |

</details>

<details>

<summary>v4.0.0</summary>

| Contract                     | Contract Address                           |
| ---------------------------- | ------------------------------------------ |
| Clanker                      | 0xE85A59c628F7d27878ACeB4bf3b35733630083a9 |
| ClankerFeeLocker             | 0x42A95190B4088C88Dd904d930c79deC1158bF09D |
| ClankerLpLockerMultiple      | 0x33e2Eda238edcF470309b8c6D228986A1204c8f9 |
| ClankerVault                 | 0xcC80d1226F899a78fC2E459a1500A13C373CE0A5 |
| ClankerAirdrop               | 0x29d17C1A8D851d7d4cA97FAe97AcAdb398D9cCE0 |
| ClankerUniv4EthDevBuy        | 0x691f97752E91feAcD7933F32a1FEdCeDae7bB59c |
| ClankerMevBlockDelay         | 0x71DB365E93e170ba3B053339A917c11024e7a9d4 |
| ClankerHookDynamicFee        | 0xE63b0A59100698f379F9B577441A561bAF9828cc |
| ClankerHookStaticFee         | 0xDFcCcfBeef7F3Fc8b16027Ce6feACb48024068cC |
| ClankerSniperAuctionV0       | 0x261fE99C4D0D41EE8d0e594D11aec740E8354ab0 |
| ClankerSniperUtilV0          | 0x8806169969aE96bfaaDb3eFd4B10785BEEb321b3 |
| ClankerLpLockerFeeConversion | 0x824bB048a5EC6e06a09aEd115E9eEA4618DC2c8f |

</details>

<details>

<summary>v3.1.0</summary>

| Contract     | Contract Address                           |
| ------------ | ------------------------------------------ |
| Clanker      | 0x2A787b2362021cC3eEa3C24C4748a6cD5B687382 |
| LpLockerv2   | 0xa1da0600Eb4A9F3D4a892feAa2c2caf80A4A2f14 |
| ClankerVault | 0xA9C0a423f0092176fC48d7B50a1fCae8cf5BB441 |

</details>

### Monad Testnet: 10143

<details>

<summary>v3.1.0</summary>

| Contract     | Contract Address                           |
| ------------ | ------------------------------------------ |
| Clanker      | 0xA0C65813DD1Cde7092922a57548Ec1eD25994318 |
| LpLockerv2   | 0xcd89C55d36097a64f777066A6cc8F2c31B7541F7 |
| ClankerVault | 0x9505A57Bf782058890f078bE301575cD75045a9b |

</details>
