> For the complete documentation index, see [llms.txt](https://clanker.gitbook.io/documentation/llms.txt). Markdown versions of documentation pages are available by appending `.md` to page URLs; this page is available as [Markdown](https://clanker.gitbook.io/documentation/references/core-contracts/v4.md).

# v4

Clanker v4 introduces a modular framework, allowing for individual components that can be swapped out and upgraded as needed. The code can be found [here](https://github.com/clanker-devco/v4-contracts).

## Core Contracts

Clanker v4 consists of three main contracts that are non-upgradeable and can be expected to remain unchanged throughout the lifetime of v4:

* **Clanker**: The factory contract responsible for token deployment, triggering pool creation, triggering liquidity placement via the LpLocker, and triggering extensions.
* [**ClankerFeeLocker**](/documentation/references/core-contracts/v4/fee-management-contracts/clankerfeelocker.md): A contract that allows users to view and claim their accumulated token fees. This single contract accrues fees for all tokens deployed on Clanker v4.0.0.
* [**ClankerToken**](broken://pages/HGVc2v9wR2qwSWuJ3phT): A super-chain compatible ERC20 contract. A new contract is deployed for every call to `deployToken()`.

Clanker v4 additionally defines four interfaces with which the Clanker factory interfaces:

* **IClankerLpLocker**: An interface for liquidity lockers to implement to be compatible with Clanker's v4 factory. The implementation is expected to manage placement of LP positions as well as collection and distribution of fees to the ClankerFeeLocker.
* **IClankerExtensions**: An interface for extensions to implement to be compatible with Clanker's v4 factory. These modules are used to add additional functionality to the token deployment process outside of LP and pool management.
* **IClankerMevModule**: An interface for MEV modules to implement to be compatible with Clanker's v4 factory. These modules are developed by the Clanker team per chain to help with MEV scenarios.
* **IClankerHook**: An interface for Uniswap v4 Hooks to implement to be compatible with the Clanker factory. These hooks are expected to contain custom logic for Clanker such as implementing our protocol fee and aiding with automatic fee collection.

All of the implementations must be allowlisted on the Clanker factory by the team to be used in deployments.

## Modular Contracts

Clanker v4 includes the following contracts which implement the above interfaces.

#### IClankerHooks:

v4.0

* [**ClankerHook**](/documentation/references/core-contracts/v4/clankerhook.md): An abstract implementation of IClankerHook which contains the implementation for Clanker's protocol fee, automatic fee claiming abilities, MEV module abilities, and fee customization abilities which the static and dynamic hooks build on top of.
* [**ClankerHookStaticFee**](/documentation/references/core-contracts/v4/clankerhook/clankerhookstaticfee.md): An extension of the ClankerHook which enables users to set a static fee for both the deployed token and the paired token.
* [**ClankerHookDynamicFee**](/documentation/references/core-contracts/v4/clankerhook/clankerhookdynamicfee.md): An extension of the ClankerHook which enables users to configure a dynamic fee that adjusts based on the amount of volatility in the pool.

v4.1

* [**ClankerHookV2**](/documentation/references/core-contracts/v4/clankerhook/clankerhookdynamicfee.md): The same as ClankerHook but with expanded capabilities including [Pool Extensions](/documentation/references/core-contracts/v4/clankerhookv2/pool-extensions.md) and mev modules that can change the applied LP fee.
* [**ClankerHookStaticFeeV2**](/documentation/references/core-contracts/v4/clankerhookv2/clankerhookstaticfeev2.md): The same as ClankerHookStaticFee except with ClankerHookV2 as the base instead of ClankerHook.
* [**ClankerHookDynamicFeeV2**](/documentation/references/core-contracts/v4/clankerhookv2/clankerhookdynamicfeev2.md): The same as ClankerHookDynamicFee except with ClankerHookV2 as the base instead of ClankerHook.

#### IClankerLPLockers:

* [**ClankerLpLockerFeeConvesrion**](/documentation/references/core-contracts/v4/fee-management-contracts/clankerlplockerfeeconversion.md): A locker implementation which enables 7 different reward recipients to be specified and 7 different initial LP positions to be placed, each able to specify which token they prefer to accumulate fees in. This locker works with the IClankerHook implementations to automatically collect LP fees on every swap and distribute the fees to reward recipients via the ClankerFeeLocker.

#### IClankerExtensions:

* [**ClankerVault**](/documentation/references/core-contracts/v4/extensions/clankervault.md): An extension that allows deployers to vault a portion of the token supply with an optional linear vest option post-unlock. The minimum lockup time is 7 days.
* [**ClankerAirdrop**](/documentation/references/core-contracts/v4/extensions/clankerairdrop.md): An extension which allows for a portion of the token supply to be allocated to airdrop recipients. Users of the extension must supply a merkle root whose leaves contain the airdrop recipient and the amount of tokens each recipient is entitled to. Lockup and linear vesting options are also available. The minimum lockup time is 1 day.
* [**ClankerAirdropV2**](/documentation/references/core-contracts/v4/extensions/clankerairdropv2.md): Similar to ClankerAirdrop but with more admin controls and the ability to change the merkle root post launch.
* [**ClankerUniv4EthDevBuy**](/documentation/references/core-contracts/v4/extensions/clankeruniv4ethdevbuy.md): An extension which allows the deployer to perform an initial swap of the token using passed-in ETH. If the paired token for the pool is not WETH, only paired tokens which have a WETH<>PairedToken UniswapV4 pool will be able to use this extension.

#### IClankerMevModule:

v4.0

* [**ClankerMevModule2BlockDelay**](/documentation/references/core-contracts/v4/mev-modules.md): A MEV module which makes the pool non-swappable for the first 2 blocks after deployment. This prevents people from front-running deployments in the same block of creation.
* [**ClankerSniperAuctionV0**](/documentation/references/core-contracts/v4/mev-modules/clankersniperauctionv0.md): A MEV module for priority ordered L2s that auctions off the first swaps on a block, directing the auction fees to token creators.

v4.1

* [**ClankerMevDescendingFees**](/documentation/references/core-contracts/v4/mev-modules/clankermevdescendingfees.md): A MEV module which enables deployers to select a starting LP fee (up to 80%), an ending fee, and a duration to decay the fee over (max 2 mintues). The fee descends parabolically.
* [**ClankerSniperAuctionV2**](/documentation/references/core-contracts/v4/mev-modules/clankersniperauctionv2.md): The same as ClankerSniperAuctionV0 but with the fee behavior of ClankerMevDescendingFees. Auctioned swaps pay the starting fee and the fee descent starts after the auction ends.
