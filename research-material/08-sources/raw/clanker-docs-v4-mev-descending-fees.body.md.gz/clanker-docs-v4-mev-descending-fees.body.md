> For the complete documentation index, see [llms.txt](https://clanker.gitbook.io/documentation/llms.txt). Markdown versions of documentation pages are available by appending `.md` to page URLs; this page is available as [Markdown](https://clanker.gitbook.io/documentation/references/core-contracts/v4/mev-modules/clankermevdescendingfees.md).

# ClankerMevDescendingFees

**ClankerMevDescendingFees** is a Mev module designed to impose higher fees on snipers. Deployers are able to specify a starting LP fee (up to 80%), an ending fee, and a time to descend (up to 2 minutes). Clanker's initial recommended configuration will start effective fees at 80% and descend to 5% over 30 seconds, after which the pool's normal fee behavior will commence. For the motivation behind these choices, see our [v4 sniper activity writeup](https://paragraph.com/@clankerworld/clanker-v4_1-sniper-tech).

The fees decay following the formula: `fee = endingFee + feeRange * (timeDecay / timeToDecay)²`.

Swaps are able to start in the second after deployment.

<figure><img src="https://3915497305-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2Fmb3xJRvIg7xvUwDkNt7y%2Fuploads%2Fgit-blob-aa4c4d8b22defe27fd09f132e828842dd4e0314a%2Fmev-descending-fees-1.png?alt=media" alt=""><figcaption></figcaption></figure>

The fee applied to the swap is the LP's fee plus Clanker's additional 20% fee. Clanker's default starting market cap is $40k USD, and with the proposed starting fee of 80%, we're setting the starting price for snipers at a market cap of $200k.

<figure><img src="https://3915497305-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2Fmb3xJRvIg7xvUwDkNt7y%2Fuploads%2Fgit-blob-ce3753a22bdb04d923677f33f4ecc9d9bf267415%2Fmev-descending-fees-2.png?alt=media" alt=""><figcaption></figcaption></figure>

### Initialization

Token deployers can configure the fee parameters with the following struct:

```solidity
struct FeeConfig {
    uint24 startingFee; // LP fee to start at
    uint24 endingFee; // LP fee to descend to
    uint256 secondsToDecay; // seconds to decay over
}
```

This config is set on the deployment struct as follows:

```solidity
address clankerMevDescendingFees; // address of the deployed MEV module
IClanker.DeploymentConfig memory deploymentConfig;

// setup the MEV module data
IClankerMevDescendingFees.FeeConfig memory feeConfig = IClankerMevDescendingFees.FeeConfig({
    startingFee: 666777, // 66%, 80% applied fee
    endingFee: 50000, // 5%
    secondsToDecay: 30 // 30 seconds
});

deploymentConfig.mevModuleConfig.mevModule = address(clankerMevDescendingFees);
deploymentConfig.mevModuleConfig.mevModuleData = abi.encode(feeConfig);
```
