-- Pool-commitment input cache for sampled arbitrage transactions.
--
-- Replace the tx_hash_values placeholder below with a comma-separated VALUES
-- body, e.g.
--
--   (0xabc...), (0xdef...)
--
-- The output is designed for compute_pool_commitment.py --dune-input-cache:
--   tx_hash, root_calldata, project_contract_addresses
--
-- Notes:
-- - project_contract_addresses comes from dex.trades and is pool-level for
--   ordinary pool contracts, but may still be a singleton/vault for protocols
--   whose Dune parser exposes the singleton as project_contract_address.
-- - root_calldata is pulled from base.transactions so commitment is measured
--   against the root transaction calldata, not callback calldata.

WITH wanted(tx_hash) AS (
    VALUES
        {{tx_hash_values}}
),

trade_pools AS (
    SELECT
        lower(CAST(d.tx_hash AS varchar)) AS tx_hash,
        array_join(
            array_sort(
                array_distinct(
                    array_agg(lower(CAST(d.project_contract_address AS varchar)))
                        FILTER (WHERE d.project_contract_address IS NOT NULL)
                )
            ),
            ','
        ) AS project_contract_addresses,
        array_join(
            array_sort(
                array_distinct(
                    array_agg(d.project || ' v' || CAST(d.version AS varchar))
                        FILTER (WHERE d.project IS NOT NULL)
                )
            ),
            ','
        ) AS dex_projects
    FROM dex.trades d
    INNER JOIN wanted w
        ON d.tx_hash = w.tx_hash
    WHERE d.blockchain = 'base'
    GROUP BY 1
)

SELECT
    lower(CAST(w.tx_hash AS varchar)) AS tx_hash,
    '0x' || to_hex(t.data) AS root_calldata,
    COALESCE(tp.project_contract_addresses, '') AS project_contract_addresses,
    COALESCE(tp.dex_projects, '') AS dex_projects
FROM wanted w
LEFT JOIN base.transactions t
    ON t.hash = w.tx_hash
LEFT JOIN trade_pools tp
    ON tp.tx_hash = lower(CAST(w.tx_hash AS varchar))
ORDER BY tx_hash;
