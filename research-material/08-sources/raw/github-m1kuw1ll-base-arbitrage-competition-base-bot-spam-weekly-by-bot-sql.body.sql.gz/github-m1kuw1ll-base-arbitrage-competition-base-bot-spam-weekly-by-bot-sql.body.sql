WITH params AS (
    SELECT
        DATE '{{start_date}}' AS start_date,
        DATE '{{end_date}}' AS end_date,
        DATE '2025-06-01' AS anchor_date,
        CAST(DATE '{{start_date}}' AS TIMESTAMP) AS start_ts,
        CAST(DATE '{{end_date}}' AS TIMESTAMP) AS end_ts
),

searchers AS (
    SELECT DISTINCT lower(CAST(bot AS varchar)) AS bot
    FROM (
        VALUES
            {{bot_values}}
    ) AS t(bot)
),

arb_hashes AS (
    SELECT DISTINCT lower(CAST(tx_hash AS varchar)) AS hash
    FROM dune.rig_ef.result_base_atomic_arbitrage
    WHERE block_time >= (SELECT start_ts FROM params)
      AND block_time <  (SELECT end_ts   FROM params)
),

week_index_bounds AS (
    SELECT
        CAST(
            floor(date_diff('day', anchor_date, start_date) / 7.0) AS integer
        ) + 1 AS first_week_number,
        CAST(
            floor(date_diff('day', anchor_date, date_add('day', -1, end_date)) / 7.0) AS integer
        ) + 1 AS last_week_number
    FROM params
),

weeks AS (
    SELECT
        week_number,
        date_add('day', 7 * (week_number - 1), (SELECT anchor_date FROM params)) AS week_start,
        date_add('day', 7 * (week_number - 1) + 6, (SELECT anchor_date FROM params)) AS week_end
    FROM week_index_bounds
    CROSS JOIN UNNEST(sequence(first_week_number, last_week_number)) AS t(week_number)
),

bot_txs AS (
    SELECT
        lower(CAST(t.hash AS varchar)) AS hash,
        lower(CAST(t."to" AS varchar)) AS bot,
        t.block_time,
        t.index AS tx_index,
        t.gas_used,
        t.gas_limit,
        t.success,
        t.value,
        CAST(
            floor(
                date_diff('day', (SELECT anchor_date FROM params), CAST(t.block_time AS DATE)) / 7.0
            ) AS integer
        ) + 1 AS week_number
    FROM base.transactions t
    INNER JOIN searchers s
        ON lower(CAST(t."to" AS varchar)) = s.bot
    WHERE t.block_time >= (SELECT start_ts FROM params)
      AND t.block_time <  (SELECT end_ts   FROM params)
),

has_swap AS (
    SELECT DISTINCT lower(CAST(d.tx_hash AS varchar)) AS hash
    FROM dex.trades d
    INNER JOIN bot_txs bt
        ON lower(CAST(d.tx_hash AS varchar)) = bt.hash
    WHERE d.blockchain = 'base'
      AND d.block_time >= (SELECT start_ts FROM params)
      AND d.block_time <  (SELECT end_ts   FROM params)
),

external_logs AS (
    SELECT DISTINCT lower(CAST(l.tx_hash AS varchar)) AS hash
    FROM base.logs l
    INNER JOIN bot_txs bt
        ON lower(CAST(l.tx_hash AS varchar)) = bt.hash
    WHERE l.block_time >= (SELECT start_ts FROM params)
      AND l.block_time <  (SELECT end_ts   FROM params)
      AND lower(CAST(l.contract_address AS varchar)) != bt.bot
),

spam_txs AS (
    SELECT
        bt.week_number,
        bt.bot,
        bt.hash AS tx_hash,
        bt.block_time,
        bt.tx_index,
        bt.gas_used,
        bt.gas_limit,
        CASE
            WHEN bt.success = false THEN 'reverted_spam'
            ELSE 'dry_run_probe'
        END AS classification
    FROM bot_txs bt
    LEFT JOIN arb_hashes a
        ON bt.hash = a.hash
    LEFT JOIN has_swap sw
        ON bt.hash = sw.hash
    LEFT JOIN external_logs ext
        ON bt.hash = ext.hash
    WHERE a.hash IS NULL
      AND (
          bt.success = false
          OR (
              bt.success = true
              AND sw.hash IS NULL
              AND ext.hash IS NULL
              AND CAST(bt.value AS double) <= 1
          )
      )
),

spam_gas_costs AS (
    SELECT
        lower(CAST(txs.hash AS varchar)) AS tx_hash,
        txs.gas_used / 1e18 * b.base_fee_per_gas AS base_fee_eth,
        txs.gas_used / 1e18 * (txs.gas_price - b.base_fee_per_gas) AS priority_fee_eth,
        txs.gas_used / 1e18 * txs.gas_price AS total_gas_fee_eth
    FROM evms.transactions txs
    INNER JOIN evms.blocks b
        ON b.blockchain = 'base'
       AND b.number = txs.block_number
       AND b.time >= (SELECT start_ts FROM params)
       AND b.time <  (SELECT end_ts   FROM params)
    WHERE txs.blockchain = 'base'
      AND txs.block_time >= (SELECT start_ts FROM params)
      AND txs.block_time <  (SELECT end_ts   FROM params)
      AND lower(CAST(txs.hash AS varchar)) IN (SELECT tx_hash FROM spam_txs)
),

per_bot_week AS (
    SELECT
        st.week_number,
        st.bot,
        SUM(CASE WHEN st.classification = 'reverted_spam' THEN 1 ELSE 0 END) AS reverted_spam_txs,
        SUM(CASE WHEN st.classification = 'dry_run_probe' THEN 1 ELSE 0 END) AS dry_run_probe_txs,
        COUNT(*) AS total_spam_txs,
        SUM(st.gas_used) AS total_spam_gas_used,
        SUM(COALESCE(sgc.base_fee_eth, 0)) AS total_spam_base_fee_eth,
        SUM(COALESCE(sgc.priority_fee_eth, 0)) AS total_spam_priority_fee_eth,
        SUM(COALESCE(sgc.total_gas_fee_eth, 0)) AS total_spam_gas_fee_eth,
        AVG(CAST(st.gas_used AS double)) AS avg_spam_gas_used,
        approx_percentile(CAST(st.gas_used AS double), 0.5) AS median_spam_gas_used
    FROM spam_txs st
    LEFT JOIN spam_gas_costs sgc
        ON sgc.tx_hash = st.tx_hash
    GROUP BY 1, 2
),

weekly_chain_totals AS (
    SELECT
        CAST(
            floor(
                date_diff('day', (SELECT anchor_date FROM params), CAST(t.block_time AS DATE)) / 7.0
            ) AS integer
        ) + 1 AS week_number,
        COUNT(*) AS total_chain_txs,
        SUM(t.gas_used) AS total_chain_gas_used
    FROM base.transactions t
    WHERE t.block_time >= (SELECT start_ts FROM params)
      AND t.block_time <  (SELECT end_ts   FROM params)
    GROUP BY 1
),

bot_week_grid AS (
    SELECT
        w.week_number,
        w.week_start,
        w.week_end,
        s.bot
    FROM weeks w
    CROSS JOIN searchers s
)

SELECT
    bw.week_number,
    bw.week_start,
    bw.week_end,
    lower(CAST(bw.bot AS varchar)) AS bot_address,
    COALESCE(pbw.reverted_spam_txs, 0) AS reverted_spam_txs,
    COALESCE(pbw.dry_run_probe_txs, 0) AS dry_run_probe_txs,
    COALESCE(pbw.total_spam_txs, 0) AS total_spam_txs,
    COALESCE(pbw.total_spam_gas_used, 0) AS total_spam_gas_used,
    COALESCE(pbw.total_spam_base_fee_eth, 0) AS total_spam_base_fee_eth,
    COALESCE(pbw.total_spam_priority_fee_eth, 0) AS total_spam_priority_fee_eth,
    COALESCE(pbw.total_spam_gas_fee_eth, 0) AS total_spam_gas_fee_eth,
    pbw.avg_spam_gas_used,
    pbw.median_spam_gas_used,
    COALESCE(wct.total_chain_txs, 0) AS total_chain_txs,
    COALESCE(wct.total_chain_gas_used, 0) AS total_chain_gas_used,
    CASE
        WHEN COALESCE(wct.total_chain_txs, 0) = 0 THEN NULL
        ELSE 100.0 * COALESCE(pbw.total_spam_txs, 0) / wct.total_chain_txs
    END AS spam_tx_pct_of_all_txs,
    CASE
        WHEN COALESCE(wct.total_chain_gas_used, 0) = 0 THEN NULL
        ELSE 100.0 * COALESCE(pbw.total_spam_gas_used, 0) / wct.total_chain_gas_used
    END AS spam_gas_pct_of_all_gas
FROM bot_week_grid bw
LEFT JOIN per_bot_week pbw
    ON pbw.week_number = bw.week_number
   AND pbw.bot = bw.bot
LEFT JOIN weekly_chain_totals wct
    ON wct.week_number = bw.week_number
ORDER BY bw.week_number, bot_address;
