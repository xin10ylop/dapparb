> For the complete documentation index, see [llms.txt](https://docs.flaunch.gg/llms.txt). Markdown versions of documentation pages are available by appending `.md` to page URLs; this page is available as [Markdown](https://docs.flaunch.gg/features/sniper-protection.md).

# Sniper Protection

Flaunch has created proprietary technology that allows web2 verification of a user to be embedded in the Flaunch AMM.

Enabling Sniper Protection when launching a coin via the [Flaunch app](https://flaunch.gg/) requires the user to validate a CAPTCHA before being able to swap during the Fair Launch period (5 minutes by default).

<figure><img src="https://1229184497-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2FoleIQgpsdD3uHYHcTay2%2Fuploads%2Fgit-blob-4fec6b2ba0ca0395831cd178ab698818cf1199f7%2FScreenshot%202025-09-11%20at%2012.51.36.png?alt=media" alt=""><figcaption></figcaption></figure>

This allows the Creator to leverage the power of hardened web2 anti-bot/proof of humanity tooling to create a better initial distribution of the coin.

{% hint style="success" %}
A "per wallet cap" can also be set to facilitate a broader distribution amongst users at launch.
{% endhint %}

If you are a builder, it's possible to create your own custom implementation of Sniper Protection that can use any offchain data to grant access to the Fair Launch period. Reach out on [Discord](https://discord.gg/PcSmznqqqb) to discuss implementation.

{% hint style="info" %}
Sniper Protection asks whether you are a person. [Game Mode](/game-mode/game-mode.md) goes further and asks what you did to deserve your allocation — access is earned by playing a game, and how much you can buy depends on how well you did.
{% endhint %}


---

# Agent Instructions
This documentation is published with GitBook. GitBook is the documentation platform designed so that both humans and AI agents can read, navigate, and reason over technical content effectively. Learn more at gitbook.com.

## Querying This Documentation
If you need additional information that is not directly available in this page, you can query the documentation dynamically by asking a question.

Perform an HTTP GET request on the current page URL with the `ask` query parameter, and the optional `goal` query parameter:

```
GET https://docs.flaunch.gg/features/sniper-protection.md?ask=<question>&goal=<endgoal>
```

`ask` is the immediate question: it should be specific, self-contained, and written in natural language.
`goal` is optional and describes the broader end goal you are ultimately trying to accomplish on behalf of the user. GitBook uses it to tailor the answer towards what is most useful for that goal.

The response will contain a direct answer to the question and relevant excerpts and sources from the documentation.

Use this mechanism when the answer is not explicitly present in the current page, you need clarification or additional context, or you want to retrieve related documentation sections.
