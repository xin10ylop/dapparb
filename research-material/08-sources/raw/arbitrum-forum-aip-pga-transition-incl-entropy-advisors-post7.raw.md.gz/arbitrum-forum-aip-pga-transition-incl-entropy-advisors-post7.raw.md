offchain | 2026-09-08 11:56:12 UTC | #1

*Evolving Arbitrum's Transaction Ordering Policy: From Timeboost to a More Open and Competitive Sequencing Market*

**UPDATE 17 August, 2026**: This proposal has been consolidated with the Fast Feed AIP and will proceed as part of a single constitutional on-chain vote. 

Both proposals completed separate Snapshot  temperature checks. 

**Update August 5, 2026**

*Should this vote pass, the ArbitrumDAO grants authority to Offchain to enable PGA and Priority Fee collection sometime after the vote is fully executed on chain*

**Update July 28, 2026**

This proposal has been amended to change how PGA is activated. Rather than activating immediately after the vote passes, priority fee collection will be controlled by a toggle that can activate or deactivate it via smart contract. This change would be executed through an ArbOwner precompile call to the `setCollectTips` function, ensuring a fast response to any situation that requires deactivating priority fee collection.

Our internal assessment of the current implementation concluded that:

- While activating priority fee collection is not itself a concern, the system needs the flexibility to be turned on and off in order to address any bugs or issues that may arise.

To help ensure the system operates correctly, the team will enable the toggle and the sequencer's PGA mode simultaneously, once the proper system testing has concluded.

This proposal has also been amended to change how the priority fee split is handled. Instead of distributing fees through the reward contract, collected priority fees will be accounted for periodically and distributed via a separate DAO vote every 6 months. Collected amounts will be published on public dashboards, allowing anyone to independently verify the validity of the accounting before each distribution vote.





**Update June 11 2026:**  *This AIP and the proposal to transition Arbitrum One to use priority fees for transaction ordering does not introduce new forms of MEV or create MEV. Just like it always has been, Arbitrum One will continue to have a private mempool at the sequencer. This means that the order of transactions are published only after the transactions have already been sequenced by the sequencer. Additionally, the ordering of transactions cannot be manipulated to extract MEV after the sequence has been published publicly. This subtle but important detail means that MEV-related sandwich attacks and frontrunning were not and are not possible on Arbitrum One.*

# Abstract

This Constitutional AIP proposes to disable Timeboost on Arbitrum One and replace it with a Priority Gas Auction (PGA) mechanism, an ordering policy that's more familiar for actors who are willing to pay for transaction priority, allowing more market participants to be a part of Arbitrum's next phase of growth. In addition, it would sunset Timeboost on Arbitrum Nova.

Timeboost was the first foray into experimenting with MEV via an express lane auction mechanism on Arbitrum One. Deploying a new transaction ordering policy (PGA) represents the next step in the journey to position Arbitrum as the premier platform for the programmable economy.

This version of a PGA-based ordering policy will first sort transactions based on priority fee in 125ms PGA rounds before publishing a block at 250ms. There will also be an anti-starvation mechanism which works as a primitive form of inclusion guarantee to help ensure that transactions that didn't get included in a round because of a low or null priority fee can be included within a couple of blocks, with the exact number determined by the number of PGA rounds.

If approved, this AIP would:

* Disable Timeboost's express lane auction on Arbitrum One and Arbitrum Nova following the successful passing of this proposal in an onchain vote.
* Enable the collection of priority fees added to transactions via an arbOwner call.
* Allow Offchain Labs to Activate PGA on Arbitrum One, enabling open, permissionless gas-price priority bidding for transaction ordering. This would be enabled via a new `TipsCollectionToggler` contract  in a similar way to the `ResourceConstraintManager` contract (previously proposed [here](https://forum.arbitrum.foundation/t/aip-raise-the-gas-target-min-l2-base-fee-implement-improvements-to-the-pricing-algorithm/30182) and activated alongside ArbOS 51 Dia).
* Establish the distribution of the new priority fee proceeds: 97% to the ArbitrumDAO Treasury and 3% to the Arbitrum Developer Guild. The split will be executed periodically via a separate DAO vote every 6 months.

Explicitly, this AIP only proposes sunsetting Timeboost on Arbitrum Nova; it does not propose adopting PGA as an ordering policy for Nova, in line with the Nova Minimization AIP https://forum.arbitrum.foundation/t/constitutional-aip-minimize-arbitrum-nova/30880

# **Motivation**

Timeboost was launched on Arbitrum One in April 2025, a novel transaction ordering policy designed to put user fairness and spam reduction at the forefront while, for the first time, creating additional revenue to the ArbitrumDAO via Timeboost auction fees. While Timeboost has delivered meaningful benefits including user fairness, and a [new revenue stream for the DAO](https://dune.com/entropy_advisors/arbitrum-dao-financials), some structural considerations have also come to light that are worth addressing:

* Timeboost's architecture represents a large barrier of entry with emerging DeFi primitives such as propAMMs, which require cheap and frequent, low-latency, priority-ordered inclusion to update onchain parameters.
* Timeboost participation remains limited as many builders that entered the auction at launch exited. Additionally, the overhead to build a custom tool that would participate in an ahead-of-time auction increased the difficulty of adoption.

A fundamentally different model is needed and the more familiar ordering policy: Priority Gas Auctions (PGA) stands out as a clear option. PGA addresses the challenges above by making ordering determined by per-transaction `priorityFeePerGas` bids rather than a periodic, ahead-of-time express lane auction:

* Competition is distributed across every transaction and every block, making collusion structurally harder.
* PGA mechanics are well-understood by CEX-DEX arbitrageurs and MEV searchers operating on other EVM chains (Ethereum, Solana, Base, OP Mainnet, Unichain), and propAMMs, lowering the barrier to entry for these participants.
* Additionally, we introduce an anti-starvation mechanism that helps facilitate that non-priority paying or low priority transactions get included within a couple of blocks. The exact wait time for a transaction is dependent on the selected parameters for the PGA round and the priority fee expressed in a transaction.

While [ArbOS 60 Elara](https://forum.arbitrum.foundation/t/constitutional-aip-arbos-60-elara/30601) introduced the **capability** for Arbitrum chains to collect priority fees (via the `maxPriorityFeePerGas` field in EIP-1559 type 2 transactions), it deliberately did not **enable** this feature on Arbitrum One or Nova. It was clearly noted that enablement would require a separate Constitutional DAO vote. This proposal would enable the collection of priority fees.

## Rationale

A new transaction ordering policy offers the ArbitrumDAO an opportunity to continue to capture additional revenue that should not come at the expense of users, with the introduction of an anti-starvation mechanism that helps facilitate transactions with 0 priority fees or low priority fees get included. Transactions remain subject to paying the latest base fees.

Rather than capturing arbitrage opportunities by having the fastest hardware or bidding ahead-of-time, participants can win these opportunities by bidding in a `just-in-time` auction to gain priority ordering.

The priority auction is permissionless and participation is open to everyone, where transactions with the highest bids get included first within a 125ms PGA round, and ties are broken by arrival timestamp.

The Arbitrum DAO can configure all aspects of PGA, including enabling or disabling it, the auction's design, and how to handle proceeds.

### Priority Fee Collection

There will be a new contract  deployed called the `TipsCollectionToggler` that will give Offchain Labs the appropriate permissions to enable and disable priority fee collection. 

This new contract will be audited by an independent third party (Trail of Bits). A full audit report will be published alongside this proposal when it gets proposed in the eventual on-chain vote. Implementing this contract will allow Offchain Labs to enable and disable priority fee collection, without the need for additional votes - should the arbitrumDAO pass this proposal.

## **Key Terms**

**Priority Fees**: are user-defined incentives paid in addition to the network's base transaction fee. Priority fees are denominated in the Arbitrum's native gas unit and are paid directly to the Arbitrum DAO Treasury.

**Priority Gas Auction**: an auction in which multiple participants simultaneously submit transactions with their specified priority fees in order to secure preferential ordering by the sequencer.

# **Specifications**

## 1. Priority Gas Auctions (PGA)

We are formally introducing our Priority Gas Auction design, which will enable Arbitrum One users to affect their transaction ordering within a block by specifying a `maxPriorityFeePerGas` in each transaction. We added some modifications in the ordering mechanism to help facilitate valid transactions with low or null priority fees are included in a timely manner, by adding a anti-starvation boost to all transactions that remain in the mempool after a PGA round.

### 1.1 How PGA Ordering Works

1. The sequencer receives a transaction and places it into a private mempool tagged with: **(a)** a priority value `p` equal to its `priorityFeePerGas` bid, and **(b)** a fine-grained arrival timestamp (at the sequencer) in milliseconds for tie-breaking.
2. Based on the arrival timestamp (at the sequencer), transactions are slotted into **PGA rounds**. Transactions arriving during a running PGA round are held and enter the sequencer's mempool only at the start of the next PGA round. Depending on the block time of the chain, which we call *B*, the PGA round time is *B/K*, for some *K* chosen by the chain operator with permission from the DAO. On Arbitrum One, given the 250ms block time and a proposed value *K* = 2, the nominal PGA round duration is **125ms**.
4. At the start of each round, all queued transactions are ranked in **descending order of** `priorityFeePerGas`, with ties broken by earliest arrival timestamp.
   1. The `priorityFeePerGas` is calculated as follows: `priority_fee_per_gas = min(transaction.max_priority_fee_per_gas, transaction.max_fee_per_gas - block.base_fee_per_gas)`
   2. Note: The sequencer collects, the computed the priority fee per gas, according to EIP-1559.
3. Transactions are appended to a block greedily until: the **32 Mgas target** is hit, the calldata limit of **95,000 bytes** is reached, or the round expires. The block hard limit is 64 Mgas; individual transactions are capped at 32 Mgas (L−T), where L is the block size limit and T is the Target size.
5. After each PGA round, if the mempool is non-empty, all waiting transactions receive a **virtual priority boost** (see section 1.2 for more details).
6. The sequencer will publish a regular block at 250 ms intervals and publishes ordered transactions within every 125ms round, via a new fast sequencer feed. In the case where a block is full before the 125ms are completed, the sequencer will start building the next block. Note: There is a limit of 8 blocks per 1 second that can be produced.

### 1.2 Anti-Starvation: Priority Boost Mechanism

This mechanism helps facilitate that transactions with null or low priority fees will get included within a reasonable time. The mechanism works as follows:

* At the end of each round, all remaining transactions receive a virtual priority fee or boost, which gets calculated by adding `p / (2K)` to all waiting transactions in the mempool, where `p` is the priority of the last transaction included in the previous PGA round, and `K` is the number of rounds per block.
* This boost is a **virtual ordering artifact only** --- it does not change the fee charged to senders.
* During the following PGA round, any transactions that were received in the previous PGA round that were not included in that round will be sorted by descending priority, taking into account the boost, before being appended to a block. This way, transactions that didn't get included in a previous PGA round due to a low/null priority fee get a virtual boost to facilitate their inclusion in the following PGA rounds.
* The sequencer must maintain a **nonce cache** for transactions with future nonces in the same fashion as its currently done today, preserving their original priority for restoration when they re-enter the mempool. Transactions in the nonce cache must NOT receive the boost.

### 1.3 Configuration Parameters

| Parameter | Default (Arb One) | Configurable By | Notes |
|----|----|----|----|
| K (rounds per block) | 2 -> 125ms rounds | Chain Operator, with permission from the DAO | Higher K = faster rounds up to a limit. Otherwise it becomes FIFO |
| Anti-starvation boost divisor | 2K | Implicitly set via K | Lower K = faster anti-starvation |

This AIP proposes granting the current sequencer operator the below rights to make the following adjustments from time to time for a period of two (2) years. The rights described below are expected to only be exercised in circumstances **where doing so would enhance PGA's long-term stability, preserve or improve the user experience for those using Arbitrum One, increase the security posture, resiliency, or stability of the chain, and/or otherwise help increase revenue for the ArbitrumDAO**:

* The right to change the `K round` parameter, a value which determines the number of rounds per block. The starting default is 2 but adjustments could be to any value between \[1 & 10\], inclusive.

## **2. Timeboost Sunset**

Upon passage of this AIP the following steps will be applied to both Arbitrum One and Arbitrum Nova:

* Timeboost users that have funds locked in the Auction contract will be able to remove their deposits anytime.
* The Timeboost autonomous auctioneer will cease accepting new bids.
* The sequencer will cease enforcing the 200ms non-express lane delay for normal transactions (note that this delay only exists when there is a Timeboost Express Lane owner).
* The express lane endpoint will be decommissioned. Any transactions submitted to this endpoint after decommissioning will be rejected.
* Any collected funds from the auctions can be flushed to the ArbitrumDAO's L2 Treasury Timelock contract at anytime, by anyone. Note that this is possible today as well.

# **Steps to Implement**

The following implementation sequence is proposed:

1. A post to the ArbitrumDAO Forums (this post) to initiate productive, collaborative discussions with the DAO and its members, followed by governance call(s) to answer any questions.
2. Temperature Check (Snapshot): This forum post will advance to a temperature check vote on Snapshot sometime after the forum post is live. The temperature check will gauge DAO sentiment on both the Timeboost sunset and a subsequent PGA activation.
3. OnChain Vote ([Alt Arbitrum Gov](https://alt.gov.arbitrum.foundation/)): Following a successful Snapshot temperature check, this proposal will proceed to an on-chain constitutional vote for \~14 days. The ArbitrumDAO will be notified on this thread and via official channels before the vote goes live.
4. PGA Activation: PGA will be activated some time after the vote passes. On the same day of activation, Timeboost’s express lane and associated delay logic will be simultaneously decomissioned.

---

# Overall Cost

The ArbitrumDAO has full control over how to spend the proceeds from the PGA auction, with 3% of auction proceeds to be set aside for the Arbitrum Developer Guild, which helps fund core Arbitrum development.

This proposal comes at no additional development cost to the ArbitrumDAO given it is already covered by an OCL and AF contract through January 2027. The engineering work will be owned by Offchain Labs in its capacity as an Arbitrum Aligned Entity.

-------------------------

nir | 2026-06-04 12:56:29 UTC | #2

Wouldn't this open the possibility for users to be frontruned and sandwiched?

-------------------------

MconnectDAO | 2026-06-05 13:30:25 UTC | #3

 Risk Management Gaps in the PGA Transition

Thank you to Offchain Labs for this detailed proposal. As a DAO governance researcher, I'd like to raise a few concerns regarding risk management that I believe should be addressed before this moves to Snapshot.

1. MEV/Frontrunning Risk  Unaddressed
   The proposal does not explicitly address how users will be protected from frontrunning and sandwich attacks under PGA. User @nir raised this concern but has not yet received a response. Unlike Timeboost's sealed Express Lane auction, PGA makes transaction ordering publicly visible via priorityFeePerGas bids  this creates a significantly larger MEV attack surface. Chains like Ethereum mainnet have seen billions lost to sandwich attacks under PGA-style ordering. Arbitrum should not replicate this without a mitigation plan.

Suggested mitigations to consider:

Optional private mempool / MEV Blocker integration for DeFi users

On-chain MEV monitoring post-launch

Clear user-facing documentation on MEV risks

2. K Parameter --- Unchecked Centralization
   The proposal grants the chain operator authority to modify K (rounds per block) between 1--10 for 2 years without DAO vote. While bounded, this still allows significant unilateral control over ordering behavior. A transparency mechanism (e.g., mandatory on-chain announcement before K changes) would strengthen governance oversight.

3. Anti-Starvation ≠ Anti-MEV
   The anti-starvation mechanism protects low-fee transactions from exclusion  but it does not protect against ordering manipulation. These are two separate problems and the proposal conflates them in its risk section.

I support the intent of this proposal and the revenue routing to the DAO Treasury. However, I'd request Offchain Labs to respond to the MEV vulnerability question before this proceeds to an onchain vote.

-------------------------

offchain | 2026-06-11 10:36:47 UTC | #4

There will be an open call to discuss this proposal. Details below: 

Thursday 11 Jun · 15:00 – 15:45 UTC
Video call link: https://meet.google.com/ayd-mrub-emr

-------------------------

leyiang | 2026-06-11 13:27:36 UTC | #5

I'm totally all for this, it's great news!

I said long ago that Timeboost would ultimately be used by only a tiny handful of whales, making Arbitrum even more centralized, and yet it took you two years to believe it. There were clearly many mature and simple alternatives. Yes, I am the one who was driven out of the Arbitrum ecosystem by the Timeboost whales. I will try to come back if this AIP effective
 https://forum.arbitrum.foundation/t/constitutional-aip-proposal-to-adopt-timeboost-a-new-transaction-ordering-policy/25167/105?u=leyiang

-------------------------

offchain | 2026-06-11 15:32:29 UTC | #6

Thanks for your feedback and questions @MconnectDAO and @nir - we have added an update at the top of this post that we hope clarifies your questions.

-------------------------

Entropy | 2026-06-16 19:47:18 UTC | #7

Entropy is supportive of this proposal and believes transitioning from Timeboost to a PGA-based ordering policy is the right move for Arbitrum at this stage.

Over the past several months, our team has spent significant time analyzing Timeboost's performance, Arbitrum's fee mechanism relative to competing chains, and the revenue implications of ArbOS 60. This research has been done in collaboration with Offchain as part of an ongoing advisory dialogue on ordering policy, and we're glad to see this proposal move forward.

Since launch, Timeboost has generated \~$7.46M in cumulative fees, which is a meaningful contribution to Arbitrum's monthly revenues. That said, the express lane has not become the default execution path for onchain MEV. 87% of atomic arbitrage and \~98% of liquidation activity on Arbitrum bypasses Timeboost entirely, and despite being live for over a year, auction participation has remained limited. As Offchain outlined in the proposal, the limited participation is largely a result of the high barrier to entry and the overhead associated with building custom tooling to participate in ahead-of-time auctions. This has led to three entities account for \~97% of all wins:

![Timeboost Auction Winner Breakdown|690x435](upload://utdJdCPi9N9or1xyDApRTXOQB2v.png)

In February 2026, Kairos emerged as a secondary marketplace, which furthered compressed competitive bidding and lowered annualized revenue. From our research on revenue capture specifically (conducted in March 2026), Timeboost was capturing just 1.74% of atomic arbitrage revenue on Arbitrum, compared to 28.83% on Ethereum via MEV-Boost and 7.34% on Base via priority fees. Much of this gap comes down to Timeboost's design where a single winner controls the express lane for an entire 60-second round and the previously mentioned dedicated bidding infrastructure to price expected MEV across that full window. The change in auction dynamics due to Kairos has pushed annualized revenue down to approximately $2M. 

![Timeboost Annualized Fees|690x435](upload://2qcq7PQol23VjUXeihpjYgLHozf.png)

Switching to PGA addresses the competitive dynamics that have limited Timeboost. As Offchain highlighted in the proposal, this is a mechanism that searchers across the EVM ecosystem are already familiar with, which should broaden participation meaningfully compared to Timeboost's custom bidding infrastructure requirement. Overall, our team views this as an important structural improvement for the network's revenues and we look forward to supporting the proposal through the offchain and onchain votes.

-------------------------

leyiang | 2026-06-18 13:16:21 UTC | #8

You have a very good point,  but I don’t think the bidding tool is the biggest obstacle for Timeboost. The real problem is clearly the design of the mechanism itself. At least for me, competing with Wintermute is impossible: when they win a one-minute slot, they can deploy a huge amount of capital and execute a massive volume of arbitrage trades, while I simply don’t have enough capital to execute that many trades. So in terms of expected profit, I can never beat them. That means my expected return in the bid has no advantage at all, and the only rational choice is to give up bidding entirely. In any case, it’s a good thing that the community has noticed.

-------------------------

offchain | 2026-06-18 16:32:32 UTC | #9

Hello! This AIP now has a live off-chain temperature check vote [here](https://snapshot.org/#/s:arbitrumfoundation.eth/proposal/0xb380013efad355a9888561e1a108f0e6344f2e39c11087bb9043378d14ecec4d).

-------------------------

Zeptimus | 2026-06-19 13:38:01 UTC | #10

Voting FOR, i like this one. This opens it up so anyone can pay for priority. way healthier. 97% of the fees go to the treasury at no dev cost too. I also like the anti-starvation piece keeps normal cheap transactions flowing, so were not squeezing regular users.

-------------------------

maxlomu | 2026-06-20 16:56:14 UTC | #11

Voting FOR on offchain and onchain votes. It's a reasonable change that opens up the priority fee to a more competitive and standardized market.

Anti-starvation is a clean mechanism for normal users to get included.

-------------------------

Abel189 | 2026-06-22 09:58:22 UTC | #12

I support this proposal.

Timeboost was an innovative experiment and successfully introduced a new revenue stream for the DAO while improving transaction ordering fairness. However, the participation model remained relatively specialized and created a higher barrier to entry for many market participants.

A PGA-based approach is easier to understand, easier to integrate with existing infrastructure, and more familiar to builders, arbitrageurs, market makers, and emerging DeFi primitives. This should help broaden participation while allowing Arbitrum to continue capturing value from transaction priority demand.

I particularly appreciate the inclusion of the anti-starvation mechanism. Maintaining a reasonable experience for users who do not actively bid for priority is important, and the proposed boost system appears to provide a practical balance between market-based ordering and transaction inclusion fairness.

Going forward, I would encourage close monitoring of user transaction costs, ordering dynamics, and the impact of future adjustments to the K parameter. Transparency around these metrics will help the community evaluate whether the new system is achieving its intended goals.

Overall, this appears to be a reasonable evolution of Arbitrum’s transaction ordering policy and a positive step toward broader participation and sustainable DAO revenue generation.

-------------------------

Griff | 2026-06-22 21:19:14 UTC | #13

Vote: FOR 

This mostly sounds good... glad we are continuing to experiment with how we charge for blockspace, Timeboost was a good experiment but if it didnt get adoption, i'm glad we can recognize that, learn from it, and pivot. 

But one thing bugs me... wtf is the Arbitrum Developer Guild? I looked it up, sounds like a sort of protocol guild thing for Arbitrum... but is it really active? Who is leading it?

-------------------------

cornellbc.eth | 2026-06-23 14:29:09 UTC | #14

Cornell Blockchain is voting FOR this proposal because we support any initiative that lowers the barrier of entry for  smaller parties to compete with bigger players, and are against the monopolization of Timeboost by 3 parties. Since Timeboost captures \~2% of atomic arbitrage revenue, with the overwhelming majority of arb and liquidation activity bypassing it entirely, then switching to PGA to bring more funds to the DAO makes sense. We also appreciate the clarification that the private mempool will protect users from sandwich attacks under PGA. Additionally, we second @abel189 comment that the transaction costs should be closely monitored, especially the choice of the k parameter, to ensure that the anti-starvation measure is working as intended.

-------------------------

Manugotsuka | 2026-06-23 14:53:24 UTC | #15

The following reflects the views of L2BEAT’s governance team, composed of @krst and @Manugotsuka, and is based on their combined research, fact-checking, and discussion.

We voted FOR.

We see this proposal as a sensible evolution of Arbitrum’s transaction ordering policy. Timeboost was a valuable experiment: it helped Arbitrum explore a new ordering model and introduced an additional revenue stream for the DAO. At the same time, it also came with complexity, and that complexity seems to have limited broader participation.

Moving to a Priority Gas Auction model feels like a more straightforward path. PGA is easier to understand, easier to integrate with existing infrastructure, and more familiar to the participants that actively compete for transaction priority. This should make the market more open while still allowing the DAO to capture value from priority demand.

We also appreciate the inclusion of the anti-starvation mechanism. A more competitive priority market should not mean that regular users are pushed aside. The proposed boost mechanism seems like a practical way to help low or zero-priority-fee transactions get included within a reasonable time.

Before voting, we asked our Research Team to review the proposal and validate the implementation path. The team did not identify any material issues and agreed that the proposed transition is worth supporting.

-------------------------

Arbitrum | 2026-06-24 09:59:03 UTC | #16

Hey @griff,

To answer your question, the[ ](https://forum.arbitrum.foundation/t/the-arbitrum-expansion-program-and-developer-guild/20722)Arbitrum Developer Guild was established to recognize and support long-term contributors whose work would strengthen the Arbitrum technology, tooling, and infrastructure. Currently, the ADG receives the following allocations for its operation: 2% of the Net Protocol Revenue share from Arbitrum chains, 3% of Timeboost fees and community donations. During the initial phase, the Arbitrum Foundation acts as a facilitator for the Guild.

For a more detailed update on the ADG, see page 27 in the[ AF’s 2025 Transparency Report](https://docs.arbitrum.foundation/assets/files/ArbitrumFoundationTransparencyReport2025-3ac117dd3203dbe7bca401cf951f0c14.pdf).

-------------------------

Flook | 2026-06-24 15:38:42 UTC | #17

Merlyn Labs is voting FOR this proposal to transition from Timeboost to Priority Gas Auctions because it should open up the priority market to broader, more standardized competition. Routing 97% of fees to the treasury at no dev cost and preserving a fair experience for regular users through the anti-starvation mechanism are big pluses as well.

-------------------------

shogun | 2026-06-25 03:42:38 UTC | #18

***The following reflects the views of GMX’s Governance Committee, and is based on the combined research, evaluation, consensus, and ideation of various committee members.***

Thanks OCL for clarifying the introduction of PGA is performed in a private sequencer mempool, to avoid frontrunning or sandwich attacks, which is important for perps users.

Timeboost was an instrumental revenue driver for Arbitrum, delivering \~$7.46M in cumulative fees, and annualised to $2M after Kairos as showcased by @Entropy. With PGA superseding Timeboost, there continues to be many use cases across perps, dex, and lending environments for a stronger usage of a `maxPriorityFeePerGas`. For GMX we observe these changes for traders, the new 125ms, private mempool based ordering mechanism is well-suited for traders interacting with GMX's platform. The revenue split of 97% to the DAO Treasury is clear to us.

Elevating the network's revenue with this AIP is a good direction for Arbitrum, and therefore voted **FOR** this proposal on Snapshot.

Our only remarks are to extend comments from @Griff:

* Who can participate in the @Arbitrum Developer Guild?
* Whose currently is in the Arbitrum Developer Guild?

-------------------------

SEEDGov | 2026-06-26 20:25:17 UTC | #19

Voted **FOR**;

We were strong supporters of Timeboost as an innovative approach to transaction ordering. For us, it demonstrated Arbitrum's willingness to experiment with different mechanisms instead of simply following existing industry standards, while creating a meaningful source of revenue for the DAO. 

With that said, we believe this proposal reflects a pragmatic next step: adopting a PGA brings Arbitrum closer to the transaction ordering model already familiar to builders and other sophisticated market participants, reducing friction for adoption while providing a more scalable foundationfor growth.

We also support the proposal because it balances economic incentives with user protections. The anti-starvation mechanism helps ensure that users are not required to compete in priority fee markets simply to have their transactions included, while the new model creates a sustainable source of revenue for the DAO.

-------------------------

Arbitrum | 2026-06-29 13:20:47 UTC | #20

[quote="shogun, post:18, topic:30942"]
* Who can participate in the @Arbitrum Developer Guild?
* Whose currently is in the Arbitrum Developer Guild?
[/quote]

The AF remains open to expressions of interest from prospective contributors. No members have yet been admitted to the Guild and the ADG will prioritize organisations with demonstrated technical capabilities as contributors.

-------------------------

shogun | 2026-07-01 10:31:34 UTC | #21

Thanks Arbitrum for the clarity. We'll be going ahead with our vote **FOR** this proposal.

-------------------------

Reverie | 2026-07-02 10:51:04 UTC | #22

* We are voting FOR this proposal. As Entropy pointed out, timeboost requires custom tooling to participate in ahead-of-time auctions which raises the overhead costs and barriers to entry to participate. This has meant that (i) concentrated the participation in timeboost to the point that 3 entities with larger balance sheets account for 97% of all auction wins, and (ii) the majority of non-CEX/DEX arbitrage txs bypass timeboost. We think that moving to a per-transaction priority-fee market should make priority access more competitive and easier for existing searchers, and new markets like propAMMs to integrate with. 

* In terms of concerns with frontrunning/MEV protection, as Offchain Labs pointed out, Arbitrum One’s sequencer continues to use a private mempool so this does not itself create a new public-mempool sandwich or frontrunning surface.

-------------------------

cornellbc.eth | 2026-08-19 18:22:45 UTC | #23

Cornell Blockchain continues to support this proposal consolidated with the Fast Feed AIP in the single Constitutional on-chain vote.

Fast Feed Rational:[ \[Constitutional\] AIP: Transition Arbitrum One ordering policy to Priority Gas Auctions (PGA) - #14 by cornellbc.eth](https://forum.arbitrum.foundation/t/constitutional-aip-fast-feed/31003/9?u=cornellbc.eth)

-------------------------

TodayInDeFi | 2026-08-21 10:59:23 UTC | #24

I supported the Fast Feed at temperature check and I'm carrying that position into the on-chain phase. On PGA, what persuades me is the data on how Timeboost actually performed. It produced real revenue — \~$7.46M cumulative — but never became the default execution path: 87% of atomic arbitrage and \~98% of liquidation activity bypassed it, and three entities took \~97% of all express-lane wins. An ahead-of-time auction that required custom tooling concentrated participation rather than opening it up. Per-transaction priority fees are a more familiar mechanism with a lower barrier to entry, and competition is spread across every transaction rather than a periodic slot.

I won't claim independent expertise on the MEV question, which is the one that matters most here. What I've leaned on is that ordering happens in the sequencer's private mempool rather than a public one, and that L2BEAT's research team and GMX's governance committee both reviewed the design on exactly that point and were satisfied. The anti-starvation boost also looks like a sensible protection for users who never bid. Sunsetting Timeboost on Nova without adopting PGA there is consistent with the minimisation path the DAO already approved.

On Fast Feed my reasoning is unchanged from July: it's a read layer on top of the sequencer after ordering is already resolved, with 97% of revenue
routed to the Treasury under the split we ratified for Timeboost and Trail of Bits audits on both contracts.

On a side note: Consolidating two separately temp-checked proposals into one atomic payload works here — both passed on their own merits — but I'd rather it not become the default.

-------------------------

AAgabriel | 2026-08-22 03:22:18 UTC | #25

I voted **FOR** this proposal.

I support the transition to PGA and the Fast Feed as a step toward a more open and competitive transaction ordering system, while also creating an additional revenue stream for the ArbitrumDAO.

I particularly appreciate that the DAO retains control over the proceeds and the ability to adjust the system as it evolves.

Looking forward to seeing how PGA performs in practice and how the additional economic activity it generates can contribute to Arbitrum’s long-term growth.

-------------------------

Zeptimus | 2026-08-24 09:44:16 UTC | #26

Voting FOR, my stance on both stays the same. PGA opens priority up to anyone, way healthier. Fast Feed is the DAO selling a product and earning revenue, thats the direction I want Arbitrum going.

-------------------------

Griff | 2026-08-24 19:59:01 UTC | #27

Voting FOR. Same yes as both snapshot rounds... Timeboost was a good experiment that didnt get adoption, glad we can learn and pivot. And love seeing us actually make money with that 97% DAO split

-------------------------

cp0x | 2026-08-26 07:54:41 UTC | #28

We support the move from Timeboost to PGA and voted FOR the combined proposal.

We checked the Toggler contract and have one implementation question.

The two-year expiry is not self-enforcing: `setCollectTips()` checks that the contract has been activated, but does not check whether `expiryTimestamp` has passed. So after year two the manager can still toggle tip collection until someone calls the permissionless `revoke()` and removes the Toggler as chain owner.

Is this behavior deliberate?

Separately, the 28 July update committed to periodic accounting of PGA proceeds, public dashboards, and a separate DAO distribution vote every six months. We expect those commitments to carry through once PGA is activated.

-------------------------

Flook | 2026-09-01 00:56:11 UTC | #29

Merlyn Labs is voting FOR this proposal.

Anything that engineers believe will make Arbitrum a more competitive technology among other blockchain options is always a yes from us.

-------------------------

Manugotsuka | 2026-09-03 16:43:15 UTC | #30

The following reflects the views of L2BEAT’s governance team, composed of @krst and @Manugotsuka, and is based on their combined research, fact-checking, and discussion.

We voted FOR.

We supported both components during their respective offchain votes ([PGA](https://forum.arbitrum.foundation/t/constitutional-aip-transition-arbitrum-one-ordering-policy-to-priority-gas-auctions-pga/30942/15?u=manugotsuka) & [Fast feed](https://forum.arbitrum.foundation/t/constitutional-aip-fast-feed/31003/16?u=manugotsuka)), and we continue to support them now that they have been combined into a single onchain proposal.

Our view remains that this direction can make Arbitrum’s transaction ordering market more accessible and easier to participate in, while still allowing the DAO to capture value from priority demand. The anti-starvation mechanism is also important, as a more competitive priority market should not come at the expense of regular users.

We also think the Fast Feed can turn economically valuable ordered transaction data into a transparent revenue product for the DAO, without changing transaction ordering, inclusion guarantees, or the fees paid by regular users.

Before the offchain votes, we asked our Research Team to review both proposals. They did not identify material issues with the PGA transition, and their view on the Fast Feed was that it may create some MEV opportunities, but not the harmful frontrunning or sandwiching behavior that would be more concerning.

For these reasons, we are reaffirming our support.

-------------------------

