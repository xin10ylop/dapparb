WITH params AS (
    SELECT
        DATE '{{start_date}}' AS start_date,
        DATE '{{end_date}}'   AS end_date,
        CAST(DATE '{{start_date}}' AS TIMESTAMP) AS start_ts,
        CAST(DATE '{{end_date}}'   AS TIMESTAMP) AS end_ts
),

aggs AS (
    SELECT * FROM (
        (
            SELECT DISTINCT project_contract_address AS tx_to
            FROM dex_aggregator.trades
            WHERE blockchain = 'base'
            AND project_contract_address IS NOT NULL
        )
        UNION
        (
            SELECT DISTINCT address AS tx_to
            FROM dex.addresses
            WHERE blockchain = 'base'
        )
    )
),

token_canonical AS (
    SELECT address, canonical_address FROM (VALUES
        (0x0000000000000000000000000000000000000000, 0x4200000000000000000000000000000000000006),
        (0x4200000000000000000000000000000000000006, 0x4200000000000000000000000000000000000006),
        (0xd9aaec86b65d86f6a7b5b1b0c42ffa531710b6ca, 0x833589fcd6edb6e08f4c7c32d4f71b54bda02913),
        (0x833589fcd6edb6e08f4c7c32d4f71b54bda02913, 0x833589fcd6edb6e08f4c7c32d4f71b54bda02913)
    ) AS t(address, canonical_address)
),

known_bots AS (
    SELECT DISTINCT tx_to AS mev_bot
    FROM (
        SELECT tx_hash,
        tx_to,
        map_filter(
            map_zip_with(
                multimap_agg(token_sold_address, -token_sold_amount),
                multimap_agg(token_bought_address, token_bought_amount),
                (k, v1, v2) -> reduce(coalesce(v1, array[]), 0, (s, x) -> s + coalesce(x, 0), s -> s)
                           + reduce(coalesce(v2, array[]), 0, (s, x) -> s + coalesce(x, 0), s -> s)
            ),
            (k, v) -> v <> 0
        ) AS balance_changes
        FROM dex.trades
        WHERE blockchain = 'base'
        AND block_date >= (SELECT start_date FROM params)
        AND block_date <  (SELECT end_date   FROM params)
        AND tx_to NOT IN (SELECT tx_to FROM aggs)
        GROUP BY 1, 2
        HAVING regexp_like(
            ARRAY_JOIN(
                ARRAY_AGG(
                    CONCAT(to_hex(token_sold_address), ',', to_hex(token_bought_address))
                    ORDER BY evt_index
                ), ','
            ),
            '^([^,]+),(?:(?:([^,]+),\2,))+\1$'
        )
    )
    WHERE all_match(map_values(balance_changes), v -> v > 0)
    AND cardinality(balance_changes) > 0
    AND tx_to NOT IN (
        SELECT DISTINCT tx_to
        FROM dex.trades d
        INNER JOIN ens.reverse_latest er
            ON er.address = d.tx_from
            AND er.name LIKE '%.base.eth'
        WHERE d.blockchain = 'base'
    )
    AND tx_to NOT IN (
        0x3fc91a3afd70395cd496c647d5a6cc9d4b2b7fad,
        0x4752ba5dbc23f44d87826276bf6fd6b1c372ad24,
        0x5ff137d4b0fdcd49dca30c7cf57e578a026d2789,
        0x1231deb6f5749ef6ce6943a275a1d3e7486f4eae,
        0x6b2c0c7be2048daa9b5527982c29f48062b34d58,
        0x6cb442acf35158d5eda88fe602221b67b400be3e,
        0x0000000000001ff3684f28c67538d4d072c22734,
        0x743f2f29cdd66242fb27d292ab2cc92f45674635,
        0xecb03b9a0e7f7b5e261d3ef752865af6621a54fe,
        0x03a520b32c04bf3beef7beb72e919cf822ed34f1,
        0x6ff5693b99212da76ad316178a184ab56d299b43,
        0xf2614a233c7c3e7f08b1f887ba133a13f1eb2c55,
        0xa238dd80c259a72e81d7e4664a9801593f98d1c5,
        0x9dda6ef3d919c9bc8885d5560999a3640431e8e6,
        0xd1ca1f4dbb645710f5d5a9917aa984a47524f49a,
        0xf6a1070fc1e76e9c6eba3478f4b1cfa6081b7a30,
        0x327df1e6de05895d2ab08513aadd9313fe505d86,
        0x1a8f43e01b78979eb4ef7febec60f32c9a72f58e,
        0x4869892c8088d9057ad7d0e5189ae8c3278f8877,
        0x1fba6b0bbae2b74586fba407fb45bd4788b7b130,
        0xfcd3842f85ed87ba2889b4d35893403796e67ff1,
        0xde44500b5d1479df5c003bf48915b3e24df3e8dd,
        0xad3b67bca8935cb510c8d18bd45f0b94f54a968f,
        0x6352a56caadc4f1e25cd6c75970fa768a3304e64,
        0xd7f1dd5d49206349cae8b585fcb0ce3d96f1696f,
        0x4cf76043b3f97ba06917cbd90f9e3a2aac1b306e,
        0x9903fbd663b3fcdd86e0414d4abc841fb3534ce9,
        0x013bb8a204499523ddf717e0abaa14e6dc849060,
        0x053bd88ae6fb19ad94d6ac781dcfc178a463436c,
        0x3e078a40c3da03e38d23a46eb2cfa5e7145441b1,
        0x0d980d465ad0df076d57662035ee29c4708c7ea4,
        0x2e86a5583a6fdfb921632876875e1053e29b2d03,
        0xba12222222228d8ba445958a75a0704d566bf2c8,
        0x5965851f21dae82ea7c62f87fb7c57172e9f2add,
        0x00000000000ba9cd9f5175108141a82b6c24d727,
        0x32bb90d28ea884587c923eba26ead5cf238db6e3,
        0x1111111254EEB25477B68fb85Ed929f73A960582,
        0x111111125421cA6dc452d289314280a0f8842A65,
        0xDef1C0ded9bec7F1a1670819833240f027b25EfF,
        0x3fC91A3afd70395Cd496C647d5a6CC9D4B2b7FAD,
        0x2626664c2603336e57b271c5c0b26f421741e481,
        0x6A000F20005980200259B80c5102003040001068,
        0x6352a56caadC4F1E25CD6c75970Fa768A3304e64,
        0x6131B5fae19EA4f9D964eAc0408E4408b66337b5,
        0x0000000000001fF3684f28c67538d4D072C22734,
        0x19ceead7105607cd444f5ad10dd51356436095a1,
        0x9008D19f58AAbD9eD0D60971565AA8510560ab41,
        0x1231DEB6f5749EF6cE6943a275A1D3E7486F4EaE,
        0xbbbbbBB520d69a9775E85b458C58c648259FAD5F,
        0x3a23F943181408EAC424116Af7b7790c94Cb97a5,
        0xbbbfd134e9b44bfb5123898ba36b01de7ab93d98,
        0x9dda6ef3d919c9bc8885d5560999a3640431e8e6,
        0xd4709066860fa8e3611c6c2659fe25e9bfefd8e0,
        0x0000000087732aaa9bf0c97398c8afa40061c057,
        0x86631c20314a54e6409c9fc61406f6a86780e4cd,
        0xf8f6bcd8d75de8154a90d45591c67049859a9469,
        0xbeef02961503351625926ea9a11ae13b29f5c555
    )
),

dec_trades AS (
    SELECT *,
        COALESCE(tc_sold.canonical_address, token_sold_address) AS token_sold_address_canonical,
        COALESCE(tc_bought.canonical_address, token_bought_address) AS token_bought_address_canonical
    FROM dex.trades t
    LEFT JOIN token_canonical tc_sold ON tc_sold.address = t.token_sold_address
    LEFT JOIN token_canonical tc_bought ON tc_bought.address = t.token_bought_address
    WHERE blockchain = 'base'
    AND block_date >= (SELECT start_date FROM params)
    AND block_date <  (SELECT end_date   FROM params)
    AND tx_to IN (SELECT mev_bot FROM known_bots)
),

arb_txs AS (
    SELECT block_number,
        block_time,
        tx_hash,
        tx_to,
        COUNT(*) AS hops,
        REPLACE(
            ARRAY_JOIN(
                ARRAY_AGG(
                    CONCAT(
                        CASE WHEN token_sold_symbol = 'WETH' THEN 'ETH' ELSE token_sold_symbol END,
                        ',',
                        CASE WHEN token_bought_symbol = 'WETH' THEN 'ETH' ELSE token_bought_symbol END
                    )
                    ORDER BY evt_index
                ), ','
            ), ',', '->'
        ) AS path,
        map_filter(
            map_zip_with(
                multimap_agg(token_sold_address, -token_sold_amount),
                multimap_agg(token_bought_address, token_bought_amount),
                (k, v1, v2) -> reduce(coalesce(v1, array[]), 0, (s, x) -> s + coalesce(x, 0), s -> s)
                           + reduce(coalesce(v2, array[]), 0, (s, x) -> s + coalesce(x, 0), s -> s)
            ),
            (k, v) -> v <> 0
        ) AS balance_changes,
        ARRAY_AGG(amount_usd ORDER BY evt_index)[1] AS volume_usd,
        ARRAY_AGG(token_sold_amount ORDER BY evt_index)[1] AS first_leg_sold_amount,
        ARRAY_AGG(project_contract_address ORDER BY evt_index)[1] AS first_pool_address,
        ARRAY_AGG(project || ' v' || CAST(version AS varchar) ORDER BY evt_index)[1] AS first_pool_project
    FROM dec_trades
    GROUP BY 1, 2, 3, 4
    HAVING regexp_like(
        ARRAY_JOIN(
            ARRAY_AGG(
                CONCAT(to_hex(token_sold_address), ',', to_hex(token_bought_address))
                ORDER BY evt_index
            ), ','
        ),
        '^([^,]+),(?:(?:([^,]+),\2,))+\1$'
    )
),

token_symbols AS (
    SELECT DISTINCT token_bought_address AS token_address,
        CASE WHEN token_bought_symbol = 'WETH' THEN 'ETH' ELSE token_bought_symbol END AS token_symbol
    FROM dec_trades
    UNION
    SELECT DISTINCT token_sold_address,
        CASE WHEN token_sold_symbol = 'WETH' THEN 'ETH' ELSE token_sold_symbol END
    FROM dec_trades
),

gas_costs AS (
    SELECT txs.hash AS tx_hash,
        txs.index AS tx_index,
        txs.gas_used AS gas_used,
        txs.gas_used / 1e18 * b.base_fee_per_gas AS base_fee_eth,
        txs.gas_used / 1e18 * (txs.gas_price - b.base_fee_per_gas) AS priority_fee_eth,
        txs.gas_used / 1e18 * txs.gas_price AS total_gas_fee_eth
    FROM evms.transactions txs
    INNER JOIN evms.blocks b
        ON b.blockchain = 'base'
        AND b.number = txs.block_number
        AND b.time >= (SELECT start_ts FROM params)
        AND b.time <  (SELECT end_ts   FROM params)
    WHERE txs.blockchain = 'base'
    AND txs.block_time >= (SELECT start_ts FROM params)
    AND txs.block_time <  (SELECT end_ts   FROM params)
    AND txs.hash IN (SELECT tx_hash FROM arb_txs)
)

SELECT a.block_number,
    a.block_time,
    a.tx_hash,
    gc.tx_index,
    a.tx_to,
    gc.gas_used,
    gc.base_fee_eth,
    gc.priority_fee_eth,
    gc.total_gas_fee_eth,
    a.path,
    a.hops,
    a.volume_usd,
    a.first_leg_sold_amount,
    a.first_pool_address,
    a.first_pool_project,
    map_keys(a.balance_changes)[1] AS token_address,
    ts.token_symbol AS token_symbol,
    map_values(a.balance_changes)[1] AS amount
FROM arb_txs a
LEFT JOIN token_symbols ts
    ON ts.token_address = map_keys(a.balance_changes)[1]
LEFT JOIN gas_costs gc
    ON gc.tx_hash = a.tx_hash
WHERE all_match(map_values(balance_changes), v -> v > 0)
AND cardinality(balance_changes) > 0
ORDER BY a.block_number ASC
