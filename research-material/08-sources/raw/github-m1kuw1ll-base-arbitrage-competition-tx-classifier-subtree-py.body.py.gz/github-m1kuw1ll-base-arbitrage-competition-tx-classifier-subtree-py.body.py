"""
Transaction-level architecture classifier for MEV bot traces.

Classifies each arbitrage transaction by observable on-chain computation
complexity using a subtree-based approach: each depth-1 call becomes its
own route attempt, classified independently.

Labels:
  OFFCHAIN_DIRECT         No market reads before execution (or only revert quotes for pricing)
  ONCHAIN_EVAL            Reads pool state on execution venues before swapping
  ONCHAIN_BROAD_SCAN      Reads confirmed pool state on extra venues beyond execution set
  NO_EXEC_REVERTED        Entire transaction reverted
  REVERT_QUOTE_ONLY       Only reverted quote calls, no execution
  PROBE_NO_EXEC           State reads but no execution
  NO_EXECUTION            No market interaction detected

Usage:
  Single trace:
    python3 ex3_classify_subtrees_txs.py --trace path/to/trace.json
    python3 ex3_classify_subtrees_txs.py --trace path/to/trace.json --json

  Batch (RPC):
    # uses .env ALCHEMY_RPC / CHAINSTACK_RPC / RPC_URL if present
    python3 ex3_classify_subtrees_txs.py \
        --csv datasets/Base_atomic_arbitrage.csv \
        --sample-per-bot 50 \
        --output arch_classification

    # explicit override
    python3 ex3_classify_subtrees_txs.py \\
        --csv datasets/Base_atomic_arbitrage.csv \\
        --rpc https://base-mainnet.core.chainstack.com/YOUR_KEY \\
        --sample-per-bot 50 \\
        --output arch_classification
"""

from __future__ import annotations

import argparse
import asyncio
import hashlib
import json
import logging
import os
import random
import time
from collections import Counter, defaultdict
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Optional


# ============================================================
# CONFIGURATION
# ============================================================

CONCURRENT_TRACES = 400
RPC_RETRY_ATTEMPTS = 3
RPC_RETRY_DELAY = 1.0
SAVE_EXAMPLE_TRACES = 3
ALCHEMY_SAFE_CONCURRENT_TRACES = 80
ALCHEMY_SAFE_MAX_RPS = 40.0
DEFAULT_RPC_PLACEHOLDER = "https://base-mainnet.core.chainstack.com/YOUR_KEY"

KNOWN_NON_ARB_BOTS = {
    "0x00000000000ba9cd9f5175108141a82b6c24d727",
    "0x32bb90d28ea884587c923eba26ead5cf238db6e3",
    "0x91c06679bd78695dc35e80a4175bc7fc2a1088b8",  # 1inch limit order arb bot
    "0x4ed4a17d539765ac3b4457bc8d0c8333fa7d8d51",  # 1inch limit order arb bot
}

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger(__name__)


# ============================================================
# SELECTOR / ADDRESS CONSTANTS
# ============================================================

TOKEN_SELECTORS = {
    "0x70a08231", "0xa9059cbb", "0x23b872dd", "0x095ea7b3",
    "0xdd62ed3e", "0x18160ddd", "0x313ce567", "0x95d89b41",
    "0x06fdde03", "0x0dfe1681", "0xd21220a7",
    "0xd0e30db0",  # WETH deposit()
    "0x2e1a7d4d",  # WETH withdraw()
}

ORACLE_SELECTORS = {
    "0xfeaf968c", "0x50d25bcd", "0x679aefce", "0x668a0f02",
}

POOL_STATE_SELECTORS = {
    "0x0902f1ac",  # getReserves (V2)
    "0x3850c7bd",  # slot0 (V3/CL)
    "0x1a686502",  # liquidity (V3/CL)
    "0x5339c296",  # tickBitmap (V3/CL)
    "0xf30dba93",  # ticks (V3/CL)
    "0xd0c93a7c",  # tickSpacing (V3/CL)
    "0xddca3f43",  # fee
    "0x883bdbfd",  # observe / snapshotCumulativesInside
    "0xe76c01e4",  # globalState
    "0x1e2eaeaf",  # getPoolState
    "0xf3cd914c",  # quoteExactSingle
}

CL_ITER_SELECTORS = {
    "0x3850c7bd", "0x1a686502", "0x5339c296", "0xf30dba93", "0xd0c93a7c",
}

DIRECT_ENTRY_SELECTORS = {
    "0x128acb08",  # Uniswap V3 style swap
    "0x022c0d9f",  # Uniswap V2 style swap
}

SYSTEM_CONTRACTS = {
    "0x420000000000000000000000000000000000000f",
    "0x4200000000000000000000000000000000000015",
    "0x4200000000000000000000000000000000000006",  # WETH
    "0x000000000000000000636f6e736f6c652e6c6f67",
}

SINGLETON_POOL_MANAGERS = {
    "0x498581ff718922c3f8e6a244956af099b2652b2b",
}

MIN_REPEATED_CALLS_FOR_CL_LOOP = 3


def load_env_file(env_file: Path = Path(".env")) -> None:
    if not env_file.exists():
        return

    for raw_line in env_file.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("export "):
            line = line[len("export ") :].strip()
        key, sep, value = line.partition("=")
        if not sep:
            continue
        key = key.strip()
        value = value.strip()
        if value and value[0] == value[-1] and value[0] in {"'", '"'}:
            value = value[1:-1]
        os.environ.setdefault(key, value)


def resolve_rpc_url(explicit_value: Optional[str]) -> str:
    if explicit_value:
        return explicit_value

    for key in ("ALCHEMY_RPC", "CHAINSTACK_RPC", "Chainstack_RPC", "RPC_URL"):
        value = os.environ.get(key)
        if value:
            return value

    return DEFAULT_RPC_PLACEHOLDER


# ============================================================
# DATA CLASS
# ============================================================

@dataclass
class SubtreeSummary:
    order: int
    top_child_idx: int
    top_to: str
    top_selector: str
    top_reverted: bool
    n_calls: int
    first_successful_write_idx: Optional[int]
    has_successful_market_write: bool
    has_reverted_quote: bool
    is_eval_only: bool
    is_successful_exec: bool
    is_direct_entry: bool
    kind: str
    n_confirmed_reads: int
    n_unconfirmed_reads: int
    n_balance_reads: int
    n_pre_quotes: int
    has_cl_eval: bool
    pre_eval_venues: list[str]
    balance_read_targets: list[str]
    exec_venues: list[str]
    extra_venues: list[str]
    resolved_helpers: list[str]


# ============================================================
# LOW-LEVEL HELPERS
# ============================================================

def norm_addr(value):
    if value is None:
        return ""
    return str(value).lower().strip()


def selector_from_input(calldata):
    if not calldata or not isinstance(calldata, str):
        return ""
    calldata = calldata.lower()
    return calldata[:10] if calldata.startswith("0x") and len(calldata) >= 10 else ""


def is_reverted(call):
    return call.get("error") is not None or call.get("ancestor_reverted", False)


def is_precompile(addr):
    if not addr or len(addr) < 3:
        return False
    try:
        value = int(addr, 16)
    except (TypeError, ValueError):
        return False
    return 0 < value <= 9


def is_infrastructure(call):
    return (
        call["selector"] in TOKEN_SELECTORS
        or call["selector"] in ORACLE_SELECTORS
        or call["to"] in SYSTEM_CONTRACTS
        or is_precompile(call["to"])
    )


def is_oracle_like(call):
    return call["selector"] in ORACLE_SELECTORS


def has_pool_state_selector(call):
    return call["selector"] in POOL_STATE_SELECTORS


def is_confirmed_pool_read(call, root_to):
    if call["to"] == root_to or not call["to"]:
        return False
    if call["type"] == "DELEGATECALL":
        return False
    if is_infrastructure(call):
        return False
    return has_pool_state_selector(call)


def is_unconfirmed_read(call, root_to):
    if call["to"] == root_to or not call["to"]:
        return False
    if call["type"] != "STATICCALL":
        return False
    if is_infrastructure(call):
        return False
    if has_pool_state_selector(call):
        return False
    return True


def is_any_market_read(call, root_to):
    return is_confirmed_pool_read(call, root_to) or is_unconfirmed_read(call, root_to)


def is_market_write_like(call, root_to):
    if call["to"] == root_to or not call["to"]:
        return False
    if call["type"] in {"STATICCALL", "DELEGATECALL"}:
        return False
    if is_infrastructure(call):
        return False
    if has_pool_state_selector(call):
        return False
    return True


def is_quote_like_reverted_call(call, root_to):
    if call["to"] == root_to or not call["to"]:
        return False
    if call["type"] in {"STATICCALL", "DELEGATECALL"}:
        return False
    if is_infrastructure(call):
        return False
    return is_reverted(call)


def extract_balance_of_target(call):
    if call["selector"] != "0x70a08231":
        return None
    calldata = call["input"].lower()
    if len(calldata) >= 74:
        return "0x" + calldata[34:74]
    return None


def compute_venue_commitment(calldata, executed_venues):
    if not executed_venues:
        return 0.0
    normalized = calldata.lower().replace("0x", "")
    if not normalized:
        return 0.0
    n_found = 0
    for venue in executed_venues:
        address = venue.lower().replace("0x", "")
        if not address:
            continue
        if address in normalized:
            n_found += 1
            continue
        padded = address.rjust(64, "0")
        if padded in normalized:
            n_found += 1
    return n_found / len(executed_venues)


# ============================================================
# FLATTEN
# ============================================================

def flatten_calls(node, out, depth=0, parent_idx=None, top_child_idx=None, ancestor_reverted=False):
    if not isinstance(node, dict):
        return
    idx = len(out)
    if depth == 1:
        top_child_idx = idx
    self_reverted = node.get("error") is not None
    out.append({
        "idx": idx,
        "parent_idx": parent_idx,
        "top_child_idx": top_child_idx,
        "depth": depth,
        "from": norm_addr(node.get("from")),
        "to": norm_addr(node.get("to")),
        "type": str(node.get("type", "")).upper(),
        "input": node.get("input", ""),
        "selector": selector_from_input(node.get("input", "")),
        "error": node.get("error"),
        "ancestor_reverted": ancestor_reverted,
    })
    child_reverted = ancestor_reverted or self_reverted
    for child in node.get("calls", []) or []:
        flatten_calls(child, out, depth=depth + 1, parent_idx=idx,
                      top_child_idx=top_child_idx, ancestor_reverted=child_reverted)


# ============================================================
# BOT ECOSYSTEM
# ============================================================

def build_bot_core(ext_calls, root_to):
    bot_core = {root_to}
    for call in ext_calls:
        if call["from"] == root_to and call["type"] == "DELEGATECALL" and call["to"]:
            bot_core.add(call["to"])
    return bot_core


def build_bot_ecosystem(ext_calls, root_to):
    bot_core = build_bot_core(ext_calls, root_to)
    recipients = set()
    for call in ext_calls:
        if (
            call["from"] in bot_core
            and call["selector"] in {"0xa9059cbb", "0x23b872dd"}
            and call["to"]
            and not is_precompile(call["to"])
        ):
            if call["selector"] == "0xa9059cbb" and len(call["input"]) >= 74:
                recipients.add("0x" + call["input"][34:74].lower())
    return bot_core | recipients


# ============================================================
# DIRECT ENTRY DETECTION
# ============================================================

def first_callback_to_bot_idx(internal_calls, bot_core):
    for call in internal_calls:
        if call["to"] in bot_core and call["from"] not in bot_core:
            return call["idx"]
    return None


def has_inventory_commit_before_callback(top_call, internal_calls, bot_core):
    cb_idx = first_callback_to_bot_idx(internal_calls, bot_core)
    if cb_idx is not None:
        return True
    for call in internal_calls:
        if call["selector"] == "0xa9059cbb" and len(call["input"]) >= 74:
            recipient = "0x" + call["input"][34:74].lower()
            if recipient in bot_core:
                return True
        if call["selector"] == "0x23b872dd" and len(call["input"]) >= 138:
            recipient = "0x" + call["input"][98:138].lower()
            if recipient in bot_core:
                return True
    return False


def has_unrelated_market_reads_before_callback(top_call, internal_calls, root_to, bot_core):
    cb_idx = first_callback_to_bot_idx(internal_calls, bot_core)
    if cb_idx is None:
        scan_calls = internal_calls
    else:
        scan_calls = [call for call in internal_calls if call["idx"] < cb_idx]

    for call in scan_calls:
        if is_confirmed_pool_read(call, root_to) and call["to"] != top_call["to"]:
            return True
        if call["type"] == "STATICCALL" and call["selector"] == "0x70a08231":
            target = extract_balance_of_target(call)
            if target and target not in bot_core and target != top_call["to"]:
                return True
    return False


def is_direct_entry_subtree(top_call, internal_calls, root_to, bot_core):
    if not is_market_write_like(top_call, root_to):
        return False, "top_not_market_write"

    if top_call["selector"] in DIRECT_ENTRY_SELECTORS:
        return True, "known_direct_entry_selector"

    committed = has_inventory_commit_before_callback(top_call, internal_calls, bot_core)
    unrelated_reads = has_unrelated_market_reads_before_callback(
        top_call, internal_calls, root_to, bot_core
    )

    if committed and not unrelated_reads:
        return True, "structural_direct_entry"

    return False, "unknown_or_helper"


# ============================================================
# SUBTREE SUMMARIZATION
# ============================================================

def summarize_subtree(order, nodes, root_to, bot_core, bot_ecosystem):
    top_call = nodes[0]
    internal_calls = nodes[1:]
    subtree_root_to = top_call["to"]
    top_balance_target = extract_balance_of_target(top_call)
    top_reverted = is_reverted(top_call)

    children_by_parent = defaultdict(list)
    for call in nodes:
        children_by_parent[call["parent_idx"]].append(call)

    def is_internal_wrapper_call(call):
        return call["from"] == subtree_root_to and call["to"] == subtree_root_to

    # Evaluation candidates
    top_eval_candidates = []
    if (
        is_confirmed_pool_read(top_call, root_to)
        or is_unconfirmed_read(top_call, root_to)
        or is_quote_like_reverted_call(top_call, root_to)
        or (
            top_call["type"] == "STATICCALL"
            and top_call["selector"] == "0x70a08231"
            and top_balance_target
            and top_balance_target not in bot_ecosystem
        )
    ):
        top_eval_candidates.append(top_call)

    eval_candidates = top_eval_candidates + [
        call for call in internal_calls if not is_internal_wrapper_call(call)
    ]
    confirmed_eval_candidates = [
        call for call in eval_candidates if is_confirmed_pool_read(call, root_to)
    ]
    unconfirmed_eval_candidates = [
        call for call in eval_candidates if is_unconfirmed_read(call, root_to)
    ]
    quote_eval_candidates = [
        call for call in eval_candidates if is_quote_like_reverted_call(call, root_to)
    ]

    # Successful writes
    internal_successful_writes = [
        call for call in eval_candidates
        if is_market_write_like(call, root_to) and not is_reverted(call)
    ]

    def is_ignorable_leaf_helper_write(call):
        return (
            top_call["selector"] in DIRECT_ENTRY_SELECTORS
            and call["from"] == top_call["to"]
            and call["selector"] not in DIRECT_ENTRY_SELECTORS
            and not children_by_parent.get(call["idx"])
            and call["to"] not in {root_to, top_call["to"]}
            and call["to"] not in bot_ecosystem
        )

    internal_successful_writes = [
        call for call in internal_successful_writes
        if not is_ignorable_leaf_helper_write(call)
    ]

    if top_reverted:
        internal_successful_writes = []

    top_is_direct_entry, _ = is_direct_entry_subtree(
        top_call, internal_calls, root_to, bot_core
    )

    if top_is_direct_entry:
        successful_writes = [] if top_reverted else [top_call]
        first_successful_write_idx = top_call["idx"] if not top_reverted else None
        pre_calls = []
        post_calls = [top_call] + internal_calls
        confirmed_reads = []
        unconfirmed_reads = []
        quote_calls = []
        balance_read_targets = set()
        pre_eval_venues = []
        exec_venues = sorted({
            call["to"] for call in post_calls
            if call["to"] and (
                is_any_market_read(call, root_to) or is_market_write_like(call, root_to)
            )
        })
        if top_call["to"]:
            exec_venues = sorted(set(exec_venues) | {top_call["to"]})
        resolved_helpers = set()
        extra_venues = []
        has_cl_eval = False
        kind = "failed_exec_attempt" if top_reverted else "successful_exec"
    else:
        successful_writes = list(internal_successful_writes)
        first_successful_write_idx = (
            min(call["idx"] for call in successful_writes) if successful_writes else None
        )

        if first_successful_write_idx is None:
            pre_calls = eval_candidates
            post_calls = []
        else:
            pre_calls = [c for c in eval_candidates if c["idx"] < first_successful_write_idx]
            post_calls = [c for c in eval_candidates if c["idx"] >= first_successful_write_idx]

        confirmed_reads = [c for c in pre_calls if is_confirmed_pool_read(c, root_to)]
        unconfirmed_reads = [c for c in pre_calls if is_unconfirmed_read(c, root_to)]
        quote_calls = [c for c in pre_calls if is_quote_like_reverted_call(c, root_to)]

        balance_read_targets = set()
        for call in pre_calls:
            if call["type"] == "STATICCALL" and call["selector"] == "0x70a08231":
                target = extract_balance_of_target(call)
                if target and target not in bot_ecosystem:
                    balance_read_targets.add(target)

        pre_eval_venues = sorted(
            {c["to"] for c in confirmed_reads if c["to"]}
            | {c["to"] for c in quote_calls if c["to"]}
        )

        exec_venues = sorted({
            c["to"] for c in post_calls
            if c["to"] and (
                is_any_market_read(c, root_to) or is_market_write_like(c, root_to)
            )
        })

        def descendant_targets(call_idx):
            stack = [call_idx]
            targets = set()
            while stack:
                current_idx = stack.pop()
                for child in children_by_parent.get(current_idx, []):
                    if child["to"]:
                        targets.add(child["to"])
                    stack.append(child["idx"])
            return targets

        resolved_helpers = set()
        for call in confirmed_reads + quote_calls:
            venue = call["to"]
            if not venue or venue in exec_venues or venue in resolved_helpers:
                continue
            if descendant_targets(call["idx"]) & set(exec_venues):
                resolved_helpers.add(venue)

        # Extra venues: only confirmed reads + balance targets trigger broad scan.
        # Revert quotes are pricing infrastructure, not discovery.
        # Venues with revert quotes have their confirmed reads treated as
        # part of the pricing workflow, not scanning evidence.
        quote_venue_set = set(c["to"] for c in quote_calls if c["to"])
        # When execution goes through a singleton pool manager, balance reads
        # within this subtree are for the PM route's pools — the bot checks
        # liquidity via balanceOf because PM hides pool addresses from call
        # targets. Don't count these as extra scanning venues.
        uses_singleton_pm = bool(set(exec_venues) & SINGLETON_POOL_MANAGERS)
        scanning_balance = set() if uses_singleton_pm else balance_read_targets
        all_scanned = set(c["to"] for c in confirmed_reads if c["to"]) | scanning_balance
        extra_venues = sorted(all_scanned - set(exec_venues) - resolved_helpers - quote_venue_set)

        by_venue = defaultdict(list)
        for call in confirmed_reads:
            by_venue[call["to"]].append(call["selector"])
        has_cl_eval = any(
            len(sels) >= MIN_REPEATED_CALLS_FOR_CL_LOOP
            and set(sels).issubset(CL_ITER_SELECTORS)
            for sels in by_venue.values()
        )

        failed_writes = [
            c for c in eval_candidates
            if is_market_write_like(c, root_to) and is_reverted(c)
        ]
        top_failed_attempt = (
            is_market_write_like(top_call, root_to)
            and is_reverted(top_call)
            and not confirmed_eval_candidates
            and not unconfirmed_eval_candidates
            and not quote_eval_candidates
        )
        has_eval_signal = bool(confirmed_reads or unconfirmed_reads or quote_calls or balance_read_targets)

        if successful_writes:
            kind = "successful_exec"
        elif quote_calls and not confirmed_reads and not unconfirmed_reads and not balance_read_targets:
            kind = "revert_quote_only"
        elif has_eval_signal:
            kind = "eval_only"
        elif failed_writes or top_failed_attempt:
            kind = "failed_exec_attempt"
        else:
            kind = "no_signal"

    return SubtreeSummary(
        order=order,
        top_child_idx=top_call["idx"],
        top_to=top_call["to"],
        top_selector=top_call["selector"],
        top_reverted=top_reverted,
        n_calls=len(nodes),
        first_successful_write_idx=first_successful_write_idx,
        has_successful_market_write=bool(successful_writes),
        has_reverted_quote=bool(quote_calls),
        is_eval_only=(kind == "eval_only"),
        is_successful_exec=(kind == "successful_exec"),
        is_direct_entry=top_is_direct_entry,
        kind=kind,
        n_confirmed_reads=len(confirmed_reads),
        n_unconfirmed_reads=len(unconfirmed_reads),
        n_balance_reads=len(balance_read_targets),
        n_pre_quotes=len(quote_calls),
        has_cl_eval=has_cl_eval,
        pre_eval_venues=pre_eval_venues,
        balance_read_targets=sorted(balance_read_targets),
        exec_venues=exec_venues,
        extra_venues=extra_venues,
        resolved_helpers=sorted(resolved_helpers),
    )


# ============================================================
# TX-LEVEL CLASSIFICATION
# ============================================================

def classify_single_trace(trace):
    """Classify a single transaction trace. Returns a dict of metrics + label."""
    calls = []
    flatten_calls(trace, calls)
    if not calls:
        return _empty_result()

    root = calls[0]
    root_to = root["to"]
    root_reverted = is_reverted(root)
    ext_calls = calls[1:]
    n_total = len(calls)

    n_reverted_d1_calls = sum(
        1 for c in ext_calls
        if c["depth"] == 1 and c["type"] == "CALL" and is_reverted(c)
    )

    base_bot_core = build_bot_core(ext_calls, root_to)
    base_bot_ecosystem = build_bot_ecosystem(ext_calls, root_to)
    has_oracle = any(is_oracle_like(c) for c in ext_calls)

    # Group by depth-1 subtree
    grouped = {}
    ordered_top_idxs = []
    for call in ext_calls:
        top_child_idx = call["top_child_idx"]
        if top_child_idx is None:
            continue
        if top_child_idx not in grouped:
            grouped[top_child_idx] = []
            ordered_top_idxs.append(top_child_idx)
        grouped[top_child_idx].append(call)

    grouped_nodes = [grouped[idx] for idx in ordered_top_idxs]

    route_attempts = [
        summarize_subtree(order, nodes, root_to, base_bot_core, base_bot_ecosystem)
        for order, nodes in enumerate(grouped_nodes)
    ]

    # Find first successful execution
    successful = [a for a in route_attempts if a.is_successful_exec]
    first_successful_route = successful[0] if successful else None
    first_success_pos = first_successful_route.order if first_successful_route else None

    # Gather pre-evaluation evidence from prior subtrees
    eval_like_before_success = []
    if first_success_pos is not None:
        eval_like_before_success = [
            a for a in route_attempts[:first_success_pos]
            if a.kind in {"eval_only", "revert_quote_only", "failed_exec_attempt"}
        ]

    # Aggregate subtree evidence
    agg_has_cl_eval = False
    for attempt in eval_like_before_success:
        if attempt.has_cl_eval:
            agg_has_cl_eval = True
    if first_successful_route and first_successful_route.has_cl_eval:
        agg_has_cl_eval = True

    # Execution venues
    used_venues = []
    if first_successful_route is not None:
        used_set = set(first_successful_route.exec_venues)
        for attempt in route_attempts[first_success_pos + 1:]:
            if attempt.is_successful_exec:
                used_set.update(attempt.exec_venues)
        used_venues = sorted(used_set)

    # Build tx_pre_calls / tx_post_calls
    reverted_d1_with_eval = sum(
        1 for a in route_attempts
        if a.top_reverted and (a.n_confirmed_reads or a.n_unconfirmed_reads or a.n_balance_reads or a.n_pre_quotes)
    )

    if first_successful_route is None:
        tx_pre_calls = []
        tx_post_calls = []
        for attempt, nodes in zip(route_attempts, grouped_nodes):
            if attempt.is_direct_entry:
                tx_post_calls.extend(nodes)
            else:
                tx_pre_calls.extend(nodes)
    else:
        tx_pre_calls = []
        tx_post_calls = []
        first_write_idx = first_successful_route.first_successful_write_idx

        for order, nodes in enumerate(grouped_nodes):
            attempt = route_attempts[order]
            if order < first_success_pos:
                if attempt.is_direct_entry:
                    tx_post_calls.extend(nodes)
                else:
                    tx_pre_calls.extend(nodes)
            elif order == first_success_pos:
                for call in nodes:
                    if first_write_idx is not None and call["idx"] < first_write_idx:
                        tx_pre_calls.append(call)
                    else:
                        tx_post_calls.append(call)
            else:
                tx_post_calls.extend(nodes)

    bot_ecosystem = set(base_bot_ecosystem)
    for call in tx_post_calls:
        if is_market_write_like(call, root_to) and call["from"]:
            bot_ecosystem.add(call["from"])

    # Pre-phase analysis
    pre_confirmed_reads = [c for c in tx_pre_calls if is_confirmed_pool_read(c, root_to)]
    pre_unconfirmed_reads = [c for c in tx_pre_calls if is_unconfirmed_read(c, root_to)]
    pre_quote_calls = [c for c in tx_pre_calls if is_quote_like_reverted_call(c, root_to)]

    pre_confirmed_venues = sorted({c["to"] for c in pre_confirmed_reads if c["to"]})
    pre_quote_venues = sorted({c["to"] for c in pre_quote_calls if c["to"]})
    pre_eval_venues = sorted(set(pre_confirmed_venues) | set(pre_quote_venues))
    pre_unconfirmed_venues = sorted(
        {c["to"] for c in pre_unconfirmed_reads if c["to"]} - set(pre_eval_venues)
    )

    balance_read_targets = set()
    for call in tx_pre_calls:
        if call["type"] == "STATICCALL" and call["selector"] == "0x70a08231":
            target = extract_balance_of_target(call)
            if target and target not in bot_ecosystem:
                balance_read_targets.add(target)

    # CL eval
    by_venue = defaultdict(list)
    for call in pre_confirmed_reads:
        by_venue[call["to"]].append(call["selector"])
    has_cl_eval = agg_has_cl_eval or any(
        len(sels) >= MIN_REPEATED_CALLS_FOR_CL_LOOP and set(sels).issubset(CL_ITER_SELECTORS)
        for sels in by_venue.values()
    )

    # Singleton pools
    calldatas_by_key = defaultdict(set)
    for call in pre_confirmed_reads:
        calldatas_by_key[(call["to"], call["selector"])].add(call["input"])
    n_singleton_pools_read = sum(
        len(v) for (addr, _), v in calldatas_by_key.items() if addr in SINGLETON_POOL_MANAGERS
    )

    # Subtree-local helper resolution
    subtree_resolved_helpers = set()
    for attempt in eval_like_before_success:
        subtree_resolved_helpers.update(attempt.resolved_helpers)
    if first_successful_route is not None:
        subtree_resolved_helpers.update(first_successful_route.resolved_helpers)

    # Reverted pre-success subtrees with ONLY balanceOf checks are route
    # viability checks on a pre-committed route that failed, not scanning.
    # Exclude their balance targets from the extra venue computation.
    # Note: n_pre_quotes may be >0 because the top-level reverted CALL itself
    # is classified as a "quote" — that's the failed route, not a quoter pattern.
    # The real test is whether there are confirmed pool state reads (slot0, etc.).
    reverted_balanceonly_targets = set()
    if first_success_pos is not None:
        for a in route_attempts[:first_success_pos]:
            if (
                a.top_reverted
                and a.n_confirmed_reads == 0
                and a.n_balance_reads > 0
            ):
                reverted_balanceonly_targets.update(a.balance_read_targets)

    # Extra venues: only confirmed reads + balance targets trigger broad scan.
    # Revert quotes are pricing infrastructure, not discovery.
    # Venues with revert quotes have their confirmed reads treated as
    # part of the pricing workflow, not scanning evidence.
    # When execution routes through a singleton pool manager, balance reads
    # from the successful subtree's own pre-phase are for the PM route —
    # the PM hides pool addresses from call targets.
    pm_route_balance_targets = set()
    if first_successful_route and (set(used_venues) & SINGLETON_POOL_MANAGERS):
        pm_route_balance_targets.update(first_successful_route.balance_read_targets)
    scanning_balance_targets = (
        balance_read_targets - reverted_balanceonly_targets - pm_route_balance_targets
    )
    all_scanned = set(pre_confirmed_venues) | scanning_balance_targets
    extra_pre_venues = sorted(
        all_scanned - set(used_venues) - subtree_resolved_helpers - set(pre_quote_venues)
    )

    # Metrics
    n_pre_eval = len(pre_eval_venues)
    n_used = len(used_venues)
    n_extra = len(extra_pre_venues)
    n_helpers = len(subtree_resolved_helpers)
    n_pre_confirmed = len(pre_confirmed_reads)
    n_pre_unconfirmed = len(pre_unconfirmed_reads)
    n_pre_quotes = len(pre_quote_calls)
    n_balance_read_targets = len(balance_read_targets)
    # Quote-only extra venues: venues revert-quoted but not in exec set.
    quote_only_extra = sorted(
        set(pre_quote_venues) - set(used_venues)
        - subtree_resolved_helpers
    )
    n_quote_extra = len(quote_only_extra)
    # Confirmed reads/balance on NON-quote venues — these indicate actual
    # on-chain evaluation, not pricing infrastructure.
    quote_venue_set = set(pre_quote_venues)
    non_quote_confirmed = [c for c in pre_confirmed_reads if c["to"] not in quote_venue_set]
    non_quote_confirmed_venues = sorted({c["to"] for c in non_quote_confirmed if c["to"]})
    non_quote_balance = balance_read_targets - quote_venue_set
    n_non_quote_confirmed = len(non_quote_confirmed)
    n_non_quote_balance = len(non_quote_balance)

    # --------------------------------------------------------
    # Classification
    # --------------------------------------------------------
    if first_successful_route is None:
        if root_reverted:
            label, confidence = "NO_EXEC_REVERTED", "medium"
            reason = "Entire transaction reverted"
        elif n_pre_quotes > 0:
            label, confidence = "REVERT_QUOTE_ONLY", "medium"
            reason = "Only reverted quote calls, no execution"
        elif n_pre_confirmed > 0 or n_balance_read_targets > 0:
            label, confidence = "PROBE_NO_EXEC", "medium"
            reason = "State reads but no execution (dry-run probe)"
        elif n_pre_unconfirmed > 0:
            label, confidence = "PROBE_NO_EXEC", "low"
            reason = "Unconfirmed reads but no execution"
        else:
            label, confidence = "NO_EXECUTION", "low"
            reason = "No market interaction detected"
    else:
        # --- Priority 1: No reads at all → off-chain ---
        if (
            n_pre_eval == 0
            and n_pre_quotes == 0
            and n_balance_read_targets == 0
            and n_pre_unconfirmed == 0
        ):
            label, confidence = "OFFCHAIN_DIRECT", "high"
            reason = "No market evaluation before first execution"

        # --- Priority 2: Extra confirmed/balance venues → broad scan ---
        # Only confirmed pool reads and balance reads on non-execution,
        # non-quoted venues trigger broad scan.
        elif n_extra > 0:
            label, confidence = "ONCHAIN_BROAD_SCAN", "high"
            reason = f"Reads {n_extra} extra venue(s) not in execution set"

        # --- Priority 3: No non-quote confirmed reads or balance reads ---
        # All confirmed reads are on quote venues (pricing infrastructure)
        # or there are only revert quotes / unconfirmed reads.
        elif n_non_quote_confirmed == 0 and n_non_quote_balance == 0:
            if n_quote_extra > 0:
                # Revert-quotes on non-execution venues: the bot is evaluating
                # alternative routes on-chain via simulated swaps.
                label, confidence = "ONCHAIN_EVAL", "medium"
                reason = (
                    f"Revert-quotes {n_quote_extra} venue(s) not in execution set "
                    f"(on-chain route evaluation)"
                )
            elif n_pre_quotes > 0:
                # Revert-quotes only on execution venues: pricing the chosen route.
                label, confidence = "OFFCHAIN_DIRECT", "high"
                reason = (
                    f"Uses {n_pre_quotes} reverted quote call(s) for exact pricing "
                    f"(off-chain route selection)"
                )
            elif n_pre_unconfirmed > 0:
                label, confidence = "OFFCHAIN_DIRECT", "low"
                reason = "No confirmed pool reads before execution"
            else:
                label, confidence = "AMBIGUOUS", "low"
                reason = "Mixed pattern"

        # --- Priority 4: Has confirmed reads or balance reads on non-quote venues ---
        # These are on execution venues (extra were caught by P2) → on-chain eval.
        else:
            label, confidence = "ONCHAIN_EVAL", "medium"
            if has_cl_eval:
                reason = "Pre-execution CL tick traversal on execution venues"
            elif n_non_quote_balance > 0 and n_non_quote_confirmed == 0:
                reason = f"Reads token balances of {n_non_quote_balance} pool(s) before execution"
            else:
                reason = f"Reads pool state on {len(non_quote_confirmed_venues)} execution venue(s) before swapping"

    # Reason annotations
    if n_pre_unconfirmed > 0:
        reason += f" [+{n_pre_unconfirmed} unconfirmed read(s) to {len(pre_unconfirmed_venues)} addr(s)]"
    if n_balance_read_targets > 0:
        reason += f" [+balanceOf on {n_balance_read_targets} pool(s)]"
    if n_quote_extra > 0:
        reason += f" [+{n_quote_extra} revert-quoted venue(s) not in exec set (pricing only)]"
    if reverted_d1_with_eval > 0:
        reason += f" [{reverted_d1_with_eval} reverted depth-1 subtree(s) contributed read evidence]"

    calldata = trace.get("input", "")
    calldata_len = (len(calldata) - 2) // 2 if calldata.startswith("0x") else len(calldata) // 2
    venue_key = ",".join(used_venues)
    route_hash = hashlib.sha256(venue_key.encode()).hexdigest()[:16] if venue_key else ""
    venue_commitment = compute_venue_commitment(calldata, used_venues)

    return {
        "label": label,
        "confidence": confidence,
        "reason": reason,
        "calldata_len": calldata_len,
        "calldata_hash": hashlib.sha256(calldata.encode()).hexdigest()[:16],
        "route_hash": route_hash,
        "executed_venues": venue_key,
        "venue_commitment": round(venue_commitment, 3),
        "n_pre_reads": n_pre_confirmed + n_pre_unconfirmed,
        "n_pre_confirmed_reads": n_pre_confirmed,
        "n_pre_unconfirmed_reads": n_pre_unconfirmed,
        "n_pre_quotes": n_pre_quotes,
        "n_pre_eval_venues": n_pre_eval,
        "n_used_venues": n_used,
        "n_extra_venues": n_extra,
        "n_quote_extra_venues": n_quote_extra,
        "n_resolved_helpers": n_helpers,
        "n_balance_read_targets": n_balance_read_targets,
        "n_singleton_pools_read": n_singleton_pools_read,
        "n_filtered_route_calls": 0,
        "n_helper_via_call": 0,
        "has_cl_eval": int(has_cl_eval),
        "has_oracle": int(has_oracle),
        "n_total_calls": n_total,
        "root_reverted": int(root_reverted),
        "n_route_attempts": len(route_attempts),
        "n_successful_routes": len(successful),
        "n_eval_only_routes": sum(a.kind == "eval_only" for a in route_attempts),
        "n_quote_only_routes": sum(a.kind == "revert_quote_only" for a in route_attempts),
        "n_failed_exec_routes": sum(a.kind == "failed_exec_attempt" for a in route_attempts),
        "n_reverted_d1_calls": n_reverted_d1_calls,
        "route_attempts_before_first_success": len(eval_like_before_success),
    }


# ============================================================
# EMPTY / LOAD
# ============================================================

def _empty_result(label="EMPTY", confidence="low", reason="No calls in trace"):
    return {
        "label": label, "confidence": confidence, "reason": reason,
        "calldata_len": 0, "calldata_hash": "", "route_hash": "",
        "executed_venues": "", "venue_commitment": 0.0,
        "n_pre_reads": 0, "n_pre_confirmed_reads": 0, "n_pre_unconfirmed_reads": 0,
        "n_pre_quotes": 0, "n_pre_eval_venues": 0, "n_used_venues": 0,
        "n_extra_venues": 0, "n_quote_extra_venues": 0, "n_resolved_helpers": 0, "n_balance_read_targets": 0,
        "n_singleton_pools_read": 0, "n_filtered_route_calls": 0, "n_helper_via_call": 0,
        "has_cl_eval": 0, "has_oracle": 0, "n_total_calls": 0, "root_reverted": 0,
        "n_route_attempts": 0, "n_successful_routes": 0, "n_eval_only_routes": 0,
        "n_quote_only_routes": 0, "n_failed_exec_routes": 0,
        "n_reverted_d1_calls": 0, "route_attempts_before_first_success": 0,
    }


def load_trace(path):
    with open(path, "r") as f:
        return json.load(f)


# ============================================================
# HUMAN-READABLE OUTPUT (for --trace mode)
# ============================================================

def print_human(path, result):
    print(f"Trace: {path}")
    print(f"Label: {result['label']} ({result['confidence']})")
    print(f"Reason: {result['reason']}")
    print(f"Venue commitment: {result['venue_commitment']}")
    print(
        f"Routes: {result['n_route_attempts']} total, "
        f"{result['n_successful_routes']} success, "
        f"{result['n_eval_only_routes']} eval, "
        f"{result['n_quote_only_routes']} quote, "
        f"{result['n_failed_exec_routes']} failed"
    )
    print("")


# ============================================================
# RPC CLIENT
# ============================================================

class RPCClient:
    def __init__(self, rpc_url, *, connector_limit=200, max_requests_per_second=None):
        self.rpc_url = rpc_url
        self.session = None
        self._req_id = 0
        self.connector_limit = connector_limit
        self.rate_limiter = AsyncRateLimiter(max_requests_per_second)

    async def __aenter__(self):
        import aiohttp
        self.session = aiohttp.ClientSession(
            timeout=aiohttp.ClientTimeout(total=300),
            connector=aiohttp.TCPConnector(limit=self.connector_limit),
        )
        return self

    async def __aexit__(self, *args):
        if self.session:
            await self.session.close()

    def _next_id(self):
        self._req_id += 1
        return self._req_id

    async def _post(self, payload):
        for attempt in range(RPC_RETRY_ATTEMPTS):
            try:
                await self.rate_limiter.acquire()
                async with self.session.post(
                    self.rpc_url, json=payload,
                    headers={"Content-Type": "application/json"},
                ) as resp:
                    retry_after = _parse_retry_after(resp.headers.get("Retry-After"))
                    data = await resp.json(content_type=None)
                    if resp.status == 429 or _is_rate_limit_error(data):
                        if attempt < RPC_RETRY_ATTEMPTS - 1:
                            delay = _compute_retry_delay(attempt, retry_after)
                            log.warning(
                                "RPC rate limited on attempt %s/%s; sleeping %.2fs",
                                attempt + 1, RPC_RETRY_ATTEMPTS, delay,
                            )
                            await asyncio.sleep(delay)
                            continue
                        return data
                    resp.raise_for_status()
                    return data
            except Exception:
                if attempt < RPC_RETRY_ATTEMPTS - 1:
                    await asyncio.sleep(_compute_retry_delay(attempt))
                else:
                    raise
        return {}

    async def debug_trace_tx(self, tx_hash, sem):
        async with sem:
            payload = {
                "jsonrpc": "2.0",
                "method": "debug_traceTransaction",
                "params": [tx_hash, {"tracer": "callTracer", "tracerConfig": {"onlyTopCall": False}}],
                "id": self._next_id(),
            }
            result = await self._post(payload)
        if "result" in result:
            return tx_hash, result["result"]
        if "error" in result:
            log.warning(f"trace error {tx_hash[:18]}: {result['error']}")
        return tx_hash, {}


# ============================================================
# BATCH CLASSIFICATION
# ============================================================

def sample_transactions(csv_path, sample_per_bot, seed=42):
    import pandas as pd
    log.info(f"Loading {csv_path}...")
    df = pd.read_csv(csv_path)
    df["tx_hash"] = df["tx_hash"].str.lower()
    df["tx_to"] = df["tx_to"].str.lower()
    n_before = len(df)
    df = df[~df["tx_to"].isin(KNOWN_NON_ARB_BOTS)]
    n_removed = n_before - len(df)
    if n_removed > 0:
        log.info(f"Removed {n_removed:,} txs from known non-arb bots")
    sampled = (
        df.groupby("tx_to", group_keys=False)
        .apply(lambda g: g.sample(n=min(len(g), sample_per_bot), random_state=seed))
    )
    log.info(f"Sampled {len(sampled):,} txs from {sampled['tx_to'].nunique()} bots")
    return sampled


def load_presampled_transactions(csv_path):
    import pandas as pd
    log.info(f"Loading presampled CSV {csv_path}...")
    df = pd.read_csv(csv_path)
    df["tx_hash"] = df["tx_hash"].str.lower()
    df["tx_to"] = df["tx_to"].str.lower()
    n_before = len(df)
    df = df[~df["tx_to"].isin(KNOWN_NON_ARB_BOTS)]
    n_removed = n_before - len(df)
    if n_removed > 0:
        log.info(f"Removed {n_removed:,} txs from known non-arb bots")
    log.info(f"Loaded {len(df):,} pre-sampled txs from {df['tx_to'].nunique()} bots")
    return df


async def fetch_and_classify(rpc, sampled_df, output_dir, cache_file, concurrent_traces):
    os.makedirs(output_dir, exist_ok=True)
    example_dir = os.path.join(output_dir, "example_traces")
    os.makedirs(example_dir, exist_ok=True)
    from tqdm import tqdm

    cache = {}
    if os.path.exists(cache_file):
        with open(cache_file, "r") as f:
            cache = json.load(f)
        log.info(f"Loaded {len(cache)} cached classifications")

    tx_to_bot = dict(zip(sampled_df["tx_hash"], sampled_df["tx_to"]))
    all_hashes = list(tx_to_bot.keys())
    uncached = [h for h in all_hashes if h not in cache]
    log.info(f"Total: {len(all_hashes)}, cached: {len(all_hashes) - len(uncached)}, to fetch: {len(uncached)}")

    examples_saved = Counter()
    sem = asyncio.Semaphore(concurrent_traces)
    pbar = tqdm(total=len(uncached), desc="Tracing & classifying")
    processed = 0

    async def do_one(tx_hash):
        nonlocal processed
        try:
            fetched_hash, trace = await rpc.debug_trace_tx(tx_hash, sem)
            if trace:
                result = classify_single_trace(trace)
                bot = tx_to_bot.get(fetched_hash, "unknown")
                if examples_saved[bot] < SAVE_EXAMPLE_TRACES:
                    with open(os.path.join(example_dir, f"{bot}_{fetched_hash[:18]}.json"), "w") as f:
                        json.dump(trace, f, indent=2)
                    examples_saved[bot] += 1
            else:
                result = _empty_result(label="ERROR", reason="Empty trace")
            cache[fetched_hash] = result
        except Exception as exc:
            cache[tx_hash] = _empty_result(label="ERROR", reason=str(exc)[:200])
        pbar.update(1)
        processed += 1
        if processed % 500 == 0:
            with open(cache_file, "w") as f:
                json.dump(cache, f)

    await asyncio.gather(*[do_one(h) for h in uncached])
    pbar.close()
    with open(cache_file, "w") as f:
        json.dump(cache, f)
    log.info(f"Cache saved: {len(cache)} entries")
    return cache


def build_tx_results(sampled_df, cache, output_dir):
    """Build tx_classification.csv from cache."""
    import pandas as pd
    os.makedirs(output_dir, exist_ok=True)

    rows = []
    for _, row in sampled_df.iterrows():
        tx_hash = row["tx_hash"]
        cls = cache.get(tx_hash, _empty_result(label="MISSING", reason="Missing cache entry"))
        rows.append({
            "tx_hash": tx_hash,
            "bot_address": row["tx_to"],
            "block_number": row.get("block_number"),
            "block_time": row.get("block_time"),
            "week_number": row.get("week_number"),
            "week_start": row.get("week_start"),
            "week_end": row.get("week_end"),
            "hops": row.get("hops"),
            **{k: cls.get(k, 0) for k in [
                "label", "confidence", "reason",
                "calldata_len", "calldata_hash", "route_hash",
                "executed_venues", "venue_commitment",
                "n_pre_reads", "n_pre_confirmed_reads", "n_pre_unconfirmed_reads",
                "n_pre_quotes", "n_pre_eval_venues", "n_used_venues",
                "n_extra_venues", "n_resolved_helpers", "n_balance_read_targets",
                "n_singleton_pools_read", "n_filtered_route_calls", "n_helper_via_call",
                "has_cl_eval", "has_oracle", "n_total_calls",
            ]},
        })

    tx_df = pd.DataFrame(rows)
    tx_path = os.path.join(output_dir, "tx_classification.csv")
    tx_df.to_csv(tx_path, index=False)

    print(f"\n{'='*80}")
    print("TX-LEVEL CLASSIFICATION SUMMARY")
    print(f"{'='*80}")
    for label, count in tx_df["label"].value_counts().items():
        pct = count / len(tx_df) * 100
        print(f"  {label:<30} {count:>6}  ({pct:>5.1f}%)")
    print(f"  {'TOTAL':<30} {len(tx_df):>6}")
    print(f"\nSaved: {tx_path}")
    return tx_df


# ============================================================
# MAIN
# ============================================================

async def run_rpc_mode(
    csv_path,
    rpc_url,
    sample_per_bot,
    output_dir,
    cache_dir,
    *,
    presampled,
    concurrent_traces,
    max_requests_per_second,
):
    if presampled:
        sampled = load_presampled_transactions(csv_path)
    else:
        sampled = sample_transactions(csv_path, sample_per_bot)
    os.makedirs(cache_dir, exist_ok=True)
    cache_file = os.path.join(cache_dir, "trace_cache.json")
    connector_limit = min(max(concurrent_traces, 1), 200)
    async with RPCClient(
        rpc_url,
        connector_limit=connector_limit,
        max_requests_per_second=max_requests_per_second,
    ) as rpc:
        cache = await fetch_and_classify(
            rpc, sampled, output_dir, cache_file, concurrent_traces
        )
    build_tx_results(sampled, cache, output_dir)


def main():
    load_env_file()
    parser = argparse.ArgumentParser(description="TX-level trace classifier")
    parser.add_argument("--trace", action="append", help="Path to trace JSON file(s)")
    parser.add_argument("--json", action="store_true", help="Print full JSON output")
    parser.add_argument("--csv", default="../datasets/Base_atomic_arbitrage_dec.csv")
    parser.add_argument(
        "--rpc",
        default=None,
        help="RPC URL. If omitted, uses ALCHEMY_RPC / CHAINSTACK_RPC / Chainstack_RPC / RPC_URL from .env.",
    )
    parser.add_argument("--sample-per-bot", type=int, default=100)
    parser.add_argument("--output", default="arch_classification_subtrees")
    parser.add_argument("--cache", default="arch_classification_subtrees/cache")
    parser.add_argument(
        "--presampled",
        action="store_true",
        help="Treat --csv as an already-sampled transaction list and skip per-bot re-sampling.",
    )
    parser.add_argument(
        "--concurrent-traces",
        type=int,
        default=None,
        help="Maximum in-flight trace requests. Defaults to a safer lower value for Alchemy URLs.",
    )
    parser.add_argument(
        "--max-rps",
        type=float,
        default=None,
        help="Cap requests per second. Defaults to a safer lower value for Alchemy URLs.",
    )
    args = parser.parse_args()

    if args.trace:
        for raw_path in args.trace:
            path = Path(raw_path)
            result = classify_single_trace(load_trace(path))
            if args.json:
                print(json.dumps({"trace": str(path), **result}, indent=2))
            else:
                print_human(path, result)
        return

    rpc_url = resolve_rpc_url(args.rpc)
    if rpc_url == DEFAULT_RPC_PLACEHOLDER:
        raise ValueError(
            "No RPC URL provided. Set ALCHEMY_RPC or CHAINSTACK_RPC in .env, or pass --rpc."
        )

    asyncio.run(run_rpc_mode(
        csv_path=args.csv, rpc_url=rpc_url,
        sample_per_bot=args.sample_per_bot,
        output_dir=args.output, cache_dir=args.cache,
        presampled=args.presampled,
        concurrent_traces=resolve_concurrent_traces(rpc_url, args.concurrent_traces),
        max_requests_per_second=resolve_max_rps(rpc_url, args.max_rps),
    ))

class AsyncRateLimiter:
    def __init__(self, max_requests_per_second):
        self.max_requests_per_second = max_requests_per_second
        self._lock = asyncio.Lock()
        self._next_allowed_at = 0.0

    async def acquire(self):
        if not self.max_requests_per_second or self.max_requests_per_second <= 0:
            return
        interval = 1.0 / self.max_requests_per_second
        async with self._lock:
            now = time.monotonic()
            wait_for = self._next_allowed_at - now
            if wait_for > 0:
                await asyncio.sleep(wait_for)
                now = time.monotonic()
            self._next_allowed_at = max(self._next_allowed_at, now) + interval


def _parse_retry_after(value):
    if not value:
        return None
    try:
        return float(value)
    except ValueError:
        return None


def _compute_retry_delay(attempt, retry_after=None):
    if retry_after is not None:
        return retry_after + random.uniform(0.0, 0.25)
    return RPC_RETRY_DELAY * (2 ** attempt) + random.uniform(0.0, 0.25)


def _is_rate_limit_error(data):
    if not isinstance(data, dict):
        return False
    error = data.get("error")
    if not isinstance(error, dict):
        return False
    code = error.get("code")
    message = str(error.get("message", "")).lower()
    return code == 429 or "compute units per second" in message or "rate limit" in message


def resolve_concurrent_traces(rpc_url, explicit_value):
    if explicit_value is not None:
        return explicit_value
    if "alchemy.com" in rpc_url:
        return ALCHEMY_SAFE_CONCURRENT_TRACES
    return CONCURRENT_TRACES


def resolve_max_rps(rpc_url, explicit_value):
    if explicit_value is not None:
        return explicit_value
    if "alchemy.com" in rpc_url:
        return ALCHEMY_SAFE_MAX_RPS
    return None


if __name__ == "__main__":
    main()
