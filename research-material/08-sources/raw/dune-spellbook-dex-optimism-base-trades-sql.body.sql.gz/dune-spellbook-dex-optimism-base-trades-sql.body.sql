{{ config(
    schema = 'dex_optimism'
    , alias = 'base_trades'
    , partition_by = ['block_month']
    , materialized = 'incremental'
    , file_format = 'delta'
    , incremental_strategy = 'merge'
    , unique_key = ['blockchain', 'project', 'version', 'tx_hash', 'evt_index']
    , incremental_predicates = [incremental_predicate('DBT_INTERNAL_DEST.block_time')]
    )
}}

{% set base_models = [
    ref('uniswap_v4_optimism_base_trades')
    , ref('uniswap_v3_optimism_base_trades')
    , ref('uniswap_v2_optimism_base_trades')
    , ref('woofi_optimism_base_trades')
    , ref('mummy_finance_optimism_base_trades')
    , ref('sushiswap_v1_optimism_base_trades')
    , ref('sushiswap_v2_optimism_base_trades')
    , ref('hashflow_optimism_base_trades')
    , ref('zipswap_optimism_base_trades')
    , ref('balancer_v2_optimism_base_trades')
    , ref('wardenswap_optimism_base_trades')
    , ref('dodo_optimism_base_trades')
    , ref('kyberswap_optimism_base_trades')
    , ref('clipper_optimism_base_trades')
    , ref('opx_finance_optimism_base_trades')
    , ref('velodrome_optimism_base_trades')
    , ref('synthetix_optimism_base_trades')
    , ref('openxswap_optimism_base_trades')
    , ref('chainhop_optimism_base_trades')
    , ref('curve_optimism_base_trades')
    , ref('rubicon_optimism_base_trades')
    , ref('gridex_optimism_base_trades')
    , ref('solidly_v3_optimism_base_trades')
    , ref('dackieswap_v2_optimism_base_trades')
    , ref('dackieswap_v3_optimism_base_trades')
    , ref('wombat_exchange_optimism_base_trades')
    , ref('elk_finance_optimism_base_trades')
    , ref('fraxswap_optimism_base_trades')
    , ref('swaap_v2_optimism_base_trades')
    , ref('timeswap_v2_optimism_base_trades')
    , ref('bridgers_optimism_base_trades')
    , ref('saddle_finance_optimism_base_trades')
    , ref('zeroex_optimism_base_trades')
    , ref('zeroex_settler_optimism_base_trades')
] %}

{{ dex_base_trades_macro(
    blockchain = 'optimism',
    base_models = base_models
) }}
